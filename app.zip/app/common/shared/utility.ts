import { Pipe, PipeTransform } from '@angular/core';
import { Injectable } from '@angular/core';
import domtoimage from 'dom-to-image';


@Injectable({
  providedIn: 'root'
})

@Pipe({ name: 'round' })
export class RoundPipe implements PipeTransform {
  transform(value) {
    return isNaN(value) ? value : parseFloat(parseFloat(value).toFixed(2));
  }
}

@Pipe({ name: 'capitalize' })
export class CapitalizePipe implements PipeTransform {
  transform(str) {
    str = str.toLowerCase().trim().replace(/_/g, " ").split(/[\s]+/);
    str = str.map(function (d) {
      d = d.charAt(0).toUpperCase() + d.slice(1);
      return d;
    })
    return str.join(" ");
  }
}

@Pipe({ name: 'nulltodash' })
export class NullToDashPipe implements PipeTransform {
  transform(val) {
    return (val == null) ? '-' : val;
  }
}

@Pipe({ name: 'reverse' })

export class ReversePipe implements PipeTransform {
  transform(value) {
    return value.slice().reverse();
  }
}

@Pipe({ name: 'division' })
export class Division implements PipeTransform {
  transform(value) {
    return value / 12;
  }
}

@Pipe({ name: 'leftzero' })
export class PaddZero implements PipeTransform {
  transform(value) {
    if (value.toString().length == 1) {
      return "0" + value;
    } else {
      return value;
    }
  }
}

export class Utils {
  public static setContainerState(el, status) {
    el = el.querySelector('.loading');
    if (status === 'nodata') {
      el.hidden = false;
      el.querySelector('.loading-img').hidden = true;
      // $('.fa-download').hide();
      // $('.fa-info-circle').hide();
      el.querySelector('.no-data').hidden = false;
    } else if (status === 'loading') {
      el.hidden = false;
      el.querySelector('.loading-img').hidden = false;
      el.querySelector('.no-data').hidden = true;
    } else if (status === 'done-loading') {
      el.hidden = true;
    }
  }

  public static dom_to_img(elm, file_name) {
    let chart: any = elm.closest(".download-wrap").querySelector('.chart');
    domtoimage.toJpeg(chart)
      .then(function (dataUrl) {
        var link = document.createElement('a');
        link.download = file_name + ".jpeg";
        link.href = dataUrl;
        link.click();
      });
  }

  public static calculateImrValues(dataset, type) {
    let sum = dataset.reduce(function (a, b) { return a + b; }),
      avg = (sum / dataset.length),
      mr = calculateMr(dataset),
      value = 0;

    function calculateMr(dataset: any) {
      let mr = 0,
        count = 0;
      for (let i = 0; i < dataset.length - 1; i++) {
        mr += Math.abs(dataset[i] - dataset[i + 1]);
        count++;
      }
      return (mr / count);
    }

    if (type == "UCL") {
      value = avg + (2.66 * mr);
    } else if (type == "LCL") {
      value = avg - (2.66 * mr);
    } else {
      value = avg;
    }

    return RoundPipe.prototype.transform(value);
  }

}