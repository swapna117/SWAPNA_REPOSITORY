import { Injectable } from "@angular/core";
import { Router } from "@angular/router";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { BehaviorSubject } from "rxjs";
import { environment } from "src/environments/environment.prod";

interface myData {
  success: boolean;
  message: string;
}

@Injectable({
  providedIn: "root"
})
export class ProjectServiceService {
  private cookieToken;
  // the actual JWT token
  public token: string;
  // the token expiration date
  public token_expires: Date;
  // error messages received from the login attempt
  public errors: any = [];

  constructor(public httpClient: HttpClient, private router: Router) { }

  // fetch all user list
  user_list() {
    return this.httpClient.get(
      environment.baseUrl + "api/auth/fetch_users/"
    );
  }

  // Edit User (Add User)
  userEdit(data) {
    return this.httpClient.put(
      environment.baseUrl + "api/auth/edit_user/",
      data
    );
  }

  // Delete User (Add User)
  delete_user(userID) {
    return this.httpClient.delete(
      environment.baseUrl + "api/auth/delete_user/" + userID + "/"
    );
  }

  // reset password for new user
  set_default_password(userID) {

    var data = "";

    return this.httpClient.put(
      environment.baseUrl + "api/auth/set_default_password/" + userID + "/",
      data
    );
  }

  // Toggle button (Add User)
  toggleUserActivation(data) {
    return this.httpClient.put(
      environment.baseUrl + "api/auth/activate_user/" + data.user_id + "/",
      data
    );
  }

  getPermissionList() {
    return this.httpClient.get(
      environment.baseUrl + "api/auth/get_role_permission/"
    );
  }

  delete_role(userID) {
    return this.httpClient.post(
      environment.baseUrl + "api/auth/delete_role/",
      userID
    );
  }

  userRoleEdit(data) {
    return this.httpClient.put(
      environment.baseUrl + "api/auth/edit_role/" + data.id + "/",
      data.actulaRoleObj
    );
  }

  getFilterData(data) {
    return this.httpClient.post(
      environment.baseUrl + "api-analytics/performer/month_percent",
      data
    );
  }

  getYearBuData() {
    return this.httpClient.get(
      environment.baseUrl + "api-analytics/year_bu_data"
    );
  }

  achievementData(data) {
    return this.httpClient.post(
      environment.baseUrl + "api-analytics/achievement/avg",
      data
    );
  }

  top_manager_data(data) {
    return this.httpClient.post(
      environment.baseUrl + "api-analytics/manager_performer/",
      data
    );
  }

  achievementsChart(data) {
    return this.httpClient.post(environment.baseUrl + "api-analytics/achievement_chart/avg", data
    );
  }

  gender_bar_graph_api(data) {
    return this.httpClient.post(environment.baseUrl + "api-analytics/gender_graph/", data)
  }

  grade_bar_graph_api(data) {
    return this.httpClient.post(environment.baseUrl + "api-analytics/grade_graph/", data)
  }
  operation_category_bar_graph_api(data) {
    return this.httpClient.post(environment.baseUrl + "api-analytics/operation_category_graph/", data)
  }

  language_count_graph_bar_graph_api(data) {
    return this.httpClient.post(environment.baseUrl + "api-analytics/language_count_graph/", data)
  }

  star_performer_graph_graph_bar_graph_api(data) {
    return this.httpClient.post(environment.baseUrl + "api-analytics/star_performer_graph/", data)
  }

  gem_performer_bar_graph_api(data) {
    return this.httpClient.post(environment.baseUrl + "api-analytics/gem_performer_graph/", data)
  }

  training_data_bar_graph_api(data) {
    return this.httpClient.post(environment.baseUrl + "api-analytics/training_data_graph/", data)
  }

  pip_data_bar_graph_api(data) {
    return this.httpClient.post(environment.baseUrl + "api-analytics/pip_data_graph/", data)
  }

  dis_data_bar_graph_api(data) {
    return this.httpClient.post(environment.baseUrl + "api-analytics/dic_data_graph/", data)
  }


  // range_apis

  leave_range_api(data) {
    return this.httpClient.post(environment.baseUrl + "api-analytics/leave_count_graph/", data)
  }

  age_range_api(data) {
    return this.httpClient.post(environment.baseUrl + "api-analytics/age_graph/", data)
  }

  experience_in_current_role_range_api(data) {
    return this.httpClient.post(environment.baseUrl + "api-analytics/experience_in_current_role_graph/", data)
  }
  performer_by_experience_in_mf_range_api(data) {
    return this.httpClient.post(environment.baseUrl + "api-analytics/performer_by_experience_in_mf_graph/", data)
  }

  tree_map(data) {
    return this.httpClient.post(environment.baseUrl + "api-analytics/tree_map/", data
    );
  }

  emp_detail_from_manager(data) {
    return this.httpClient.post(environment.baseUrl + "api-analytics/emp_detail_from_manager/", data);
  }


  d_month_avg(data) {
    return this.httpClient.post(environment.baseUrl + "api-analytics/performer/low_month_percent", data);
  }

  a_month_avg(data) {
    return this.httpClient.post(environment.baseUrl + "api-analytics/performer/high_month_percent", data);
  }

  b_month_avg(data) {
    return this.httpClient.post(environment.baseUrl + "api-analytics/performer/b_month_percent/", data);
  }

  c_month_avg(data) {
    return this.httpClient.post(environment.baseUrl + "api-analytics/performer/c_month_percent/", data);
  }

  insightgraphstackbarRange(data){
    console.log("1111111111111", data);  
    return this.httpClient.post(environment.baseUrl + "api/insight/stackbarRange/", data)
  }
  insightgraphstackbar(data){
    console.log("1111111111111", data);  
    return this.httpClient.post(environment.baseUrl + "api/insight/stackbar/", data)
  }
  compemsation_data(data){
    return this.httpClient.post(environment.baseUrl + "api-analytics/compensatio_data/", data)


  }
  tier_data(data){
    return this.httpClient.post(environment.baseUrl + "api-analytics/tier_data/", data)


  }


}

