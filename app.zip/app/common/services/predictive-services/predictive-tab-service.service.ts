import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class PredictiveTabServiceService {

  constructor( public httpClient: HttpClient, private router: Router) { }


  get_predict_state_data(data) {
    return this.httpClient.post(environment.baseUrl + 'api-predictive/state_predictive/',data);
  }
  
  state_list(){
    return this.httpClient.get(environment.baseUrl + "api/simulation/data_load/")
  }

  get_pdb_dropdown(){
    return this.httpClient.get(environment.baseUrl + "api-predictive/pdb_dropdown/");
  }

  get_pdb_data(data){
    return this.httpClient.post(environment.baseUrl + "api-predictive/pdb_curve/",data);
  }

  simulation_data(data){
    return this.httpClient.post(environment.baseUrl + "api/simulation/get_simulation_data/",data);
  }

  get_low_high_predictive_data(){
    return this.httpClient.get(environment.baseUrl + "api-predictive/high_low_predictive_data/");
  }
  employee_data(emp_id){
    return this.httpClient.post(environment.baseUrl + "api/simulation/emp_detail/",emp_id)
  }

  employee_name_list(emp_name){
    return this.httpClient.post(environment.baseUrl + "api/simulation/emp_detail_data/",emp_name)
  }

  predictive_emp_list(data){
    return this.httpClient.post(environment.baseUrl + "api-predictive/get_rbmi_data/",data)
  }

  predictive_tree_map_list(data){
    return this.httpClient.post(environment.baseUrl + "api-predictive/state_predictive/",data)
  }
  lime_explainer_graph_data(data){
    return this.httpClient.post(environment.baseUrl + "api/simulation/lime_explainer/",data)
  }
  get_predictive_parameter_service(data){
    return this.httpClient.post(environment.baseUrl + "api-predictive/parameter_predict_data/",data)
  }

  get_pred_tier_data(data){
    return this.httpClient.post(environment.baseUrl + "api-predictive/get_tier_data/",data)
  }
  

}
