import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment.prod';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class ModelHealthService {

  constructor( public httpClient: HttpClient, private router: Router) { }


  get_model_health_data() {
    return this.httpClient.get(environment.baseUrl + 'api-modelhealth/insights/');
  }
  insert_model_health_data() {
    return this.httpClient.get(environment.baseUrl + 'api-modelhealth/insertmodelhealth/');
  }


get_line_chart_data(){
  return this.httpClient.get(environment.baseUrl + 'api-modelhealth/roc_chart/');


}
}