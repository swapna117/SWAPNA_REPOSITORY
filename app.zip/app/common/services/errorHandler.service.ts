import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { AuthService } from './auth.service';
import { Router } from "@angular/router";
declare var $: any;

@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
    constructor(private AuthService: AuthService, private router: Router) { }

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

        if (req.url.indexOf('/reset_password') > 1 || req.url.indexOf('/login') > 1) {
            return next.handle(req);
        }

        return next.handle(req).pipe(catchError(err => {
            if (err.status === 401) {
                $('.modal-backdrop').remove();
                this.AuthService.logout();
                setTimeout(function() {
                    $('.sesson-modal').modal('show');
                }, 300);  
            } 


            if (err.status === 403){
                $(".dashboard-content").hide()
                $(".no-permission").show()
            }

            const error = err.error.message || err.statusText;
            return throwError(error);
        }))
    }
}
