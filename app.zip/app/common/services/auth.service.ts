import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment.prod';

interface myData {
  success: boolean,
  message: string
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(public httpClient: HttpClient, private router: Router) { }

  //login
  login_user(data) {
    return this.httpClient.post<myData>(environment.baseUrl + 'api/auth/login/', data)
  }

  // forgot_password(data) {
  //   return this.httpClient.post(environment.baseUrl + 'api/auth/forgot_password/', data)
  // }

  // Signup

  create_user(data) {
    return this.httpClient.post(environment.baseUrl + 'api/auth/signup/', data)
  }

  //Create Role

  createRole(data) {
    return this.httpClient.post(environment.baseUrl + 'api/auth/add_role/', data)
  }


  // Fetch Role Data

  getRoleData() {
    return this.httpClient.get(environment.baseUrl + 'api/auth/get_role/');
  }

  //change password 

  change_password(data) {
    return this.httpClient.patch(environment.baseUrl + 'api/auth/change_password/', data);
  }

  //reset password

  reset_password(data) {
    return this.httpClient.post(environment.baseUrl + 'api/auth/reset_password/', data);
  }

  // Permission list

  getPermissions() {
    return this.httpClient.get(environment.baseUrl + 'api/auth/get_permission/');
  }

  // Logout

  logout() {
    localStorage.clear()
    this.router.navigate(['/']);
  }
}
