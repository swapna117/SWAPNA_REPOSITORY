import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject } from 'rxjs';
import { environment } from 'src/environments/environment.prod';

interface myData {
  success: boolean;
  message: string;
}

@Injectable({
  providedIn: 'root'
})
export class LoaderService {

  constructor(public httpClient: HttpClient, private router: Router) { }
  private getOptions() {
    return  {
      headers:  new HttpHeaders().set('Authorization', 'Token ' + localStorage.getItem('token'))
    };
  }

  dropdown_data() {
    return this.httpClient.get(environment.baseUrl + 'api/loader/dropdown_data/')
  }
  

  save_file(files, table_name) {
    const formData: FormData = new FormData();
    for (let index = 0; index < files.length; index++) {
      const element = files[index];
      formData.append('file', element,element.name); 
    }
    formData.append('table_name', table_name);

    return this.httpClient.post(environment.baseUrl + 'api/loader/file/', formData,{
      reportProgress:true,
      observe:"events",
    })
  }

  // Download Loading Templates
 
  public async downloadResource(): Promise<Blob> {
    let url = environment.baseUrl +'api/loader/download/',
        options = this.getOptions();
    options['responseType'] = 'blob' as 'json';
    const file =  await this.httpClient.get<Blob>(url,options).toPromise();
    return file;
  }

  refresh_data(){
    return this.httpClient.get(environment.baseUrl + "api/loader/refresh_view/")
  }
}


