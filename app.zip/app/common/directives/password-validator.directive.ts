export { Validator, NG_VALIDATORS } from '@angular/forms';
import { Directive, Input } from '@angular/core';
import { Validator, NG_VALIDATORS, AbstractControl } from '@angular/forms';

@Directive({
    selector: '[appPasswordValidator]',
    providers: [{
        provide: NG_VALIDATORS,
        useExisting: PasswordValidator,
        multi:true
    }]
})

export class PasswordValidator implements Validator{
    @Input() appPasswordValidator
    validate(control:AbstractControl): {[key:string]:any} | null{
        const controlToCompare = control.parent.get(this.appPasswordValidator);
        if(controlToCompare && controlToCompare.value != control.value){
            return {'notEqual':true};
        }

        return null;
    }
}