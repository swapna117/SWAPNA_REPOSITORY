import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Router, ParamMap, NavigationEnd } from "@angular/router";
import { AuthService } from "src/app/common/services/auth.service";

@Component({
  selector: "app-navbar",
  templateUrl: "./navbar.component.html",
  styleUrls: ["./navbar.component.css"]
})
export class NavbarComponent implements OnInit {
  role: string;
  permissionArr: any = [];
  local_arr: any;
  currentUrl:any;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private service: AuthService
  ) { router.events.subscribe((_: NavigationEnd) => this.currentUrl = this.router.url);
  }

  ngOnInit() {
    this.role = localStorage.getItem("roleName");
    this.local_arr = localStorage.getItem("permissions");
    this.permissionArr = this.local_arr.split(",");
  }

  showUser() {
    this.router.navigate(["/user_management"], {
      relativeTo: this.route
    });
  }

  showRole() {
    this.router.navigate(["/role_management"], {
      relativeTo: this.route
    });
  }
  showDashboard() {
    this.router.navigate(["/descriptive-analytics"], { relativeTo: this.route });
  }


  showPredictive(){
    this.router.navigate(["/predictive-analytics"], { relativeTo: this.route });
  }

  
  showLoader() {
    this.router.navigate(["/loader"], { relativeTo: this.route });
  }

  Onlogout() {
    this.service.logout();
  }
}
