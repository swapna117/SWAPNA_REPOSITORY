import { Component, OnInit, Output, EventEmitter, ViewChild } from '@angular/core';
import { PredictiveTabServiceService } from 'src/app/common/services/predictive-services/predictive-tab-service.service';
import { DataTableDirective } from 'angular-datatables';
import { HttpClient } from '@angular/common/http';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-emp-search',
  templateUrl: './emp-search.component.html',
  styleUrls: ['./emp-search.component.css']
})
export class EmpSearchComponent implements OnInit {

  constructor(private service: PredictiveTabServiceService,
    public httpClient: HttpClient) { }
  model_value: any = "";

  model: any = {
    emp_id: ""
  };
  success_message: any = "";
  empname: any = {}
  emp_data: any;
  emp_details: any = {};
  employee_list: any = [];
  emp_arr: any = [];
  @Output() public childEvent = new EventEmitter;

  @ViewChild(DataTableDirective)
  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {};
  dtTrigger: any = new Subject();


  ngOnInit() {

  }


  simulateSubmit() {
    this.plot_roleTable()
    this.model = { emp_id: "" };
    this.employee_list.length = 0
    $(".text-danger").hide()

    if (this.model_value.match(/^[a-zA-Z ]*$/)) {
      this.empname.empname = this.model_value
      this.service.employee_name_list(this.empname).subscribe((res: any) => {
        this.employee_list = res.data;
        this.emp_arr.length = 0

        for (let i of this.employee_list) {
          this.emp_arr.push(i)
        }
        if (!this.dtElement.dtInstance) {
          this.dtTrigger.next();
        } else {
          this.rerender()
        };
      })
      $("#emp_list_modal").modal("show")
    }
    else {
      this.model.emp_id = this.model_value
      this.model.empname = ''
      this.getEmployeeService(this.model)
    }

  }

  getEmployeeService(data) {
    this.service.employee_data(data).subscribe((res: any) => {
      this.success_message = res.message
      if (res.message) {
        $(".text-danger").show()
      } else {
        this.emp_data = res
        this.emp_data.extension_of_probation

        if (this.emp_data["emp_age"] !== null) {
          this.emp_details["emp_age"] = this.emp_data["emp_age"]
        } else {
          this.emp_details["emp_age"] = 15
        }

        if (this.emp_data["repo_age"] !== null) {
          this.emp_details["repo_age"] = this.emp_data["repo_age"]
        } else {
          this.emp_details["repo_age"] = 15
        }

        if (this.emp_data["experience_in_current_role"] !== null) {
          this.emp_details["experience_in_current_role"] = (this.emp_data.experience_in_current_role / 12).toFixed(1)
        } else {
          this.emp_details["experience_in_current_role"] = 0
        }

        if (this.emp_data["total_experience_in_mf"] !== null) {
          this.emp_details["total_experience_in_mf"] = (this.emp_data.total_experience_in_mf / 12).toFixed(1)
        } else {
          this.emp_details["total_experience_in_mf"] = 0
        }

        if (this.emp_data["repo_total_experience_in_mf"] !== null) {
          this.emp_details["repo_total_experience_in_mf"] = (this.emp_data.repo_total_experience_in_mf / 12).toFixed(1)
        } else {
          this.emp_details["repo_total_experience_in_mf"] = 0
        }

        if (this.emp_data["repo_experience_in_current_role"] !== null) {
          this.emp_details["repo_experience_in_current_role"] = (this.emp_data.repo_experience_in_current_role / 12).toFixed(1)
        } else {
          this.emp_details["repo_experience_in_current_role"] = 0
        }

        if (this.emp_data["no_leaves_taken"] !== null) {
          this.emp_details["no_leaves_taken"] = this.emp_data.no_leaves_taken
        } else {
          this.emp_details["no_leaves_taken"] = 0
        }

        if (this.emp_data["no_lang_known"] !== null) {
          this.emp_details["no_lang_known"] = this.emp_data.no_lang_known
        } else {
          this.emp_details["no_lang_known"] = 0
        }

        if (this.emp_data["repo_no_lang_known"] !== null) {
          this.emp_details["repo_no_lang_known"] = this.emp_data.repo_no_lang_known
        } else {
          this.emp_details["repo_no_lang_known"] = 0
        }

        if (this.emp_data.extension_of_probation !== null) {
          this.emp_details["extension_of_probation"] = this.emp_data.extension_of_probation
        } else {
          this.emp_details["extension_of_probation"] = 0
        }

        if (this.emp_data.contract !== null) {
          this.emp_details["contract"] = this.emp_data.contract
        } else {
          this.emp_details["contract"] = 0
        }

        if (this.emp_data.monthly_compens_gross !== null) {
          this.emp_details["monthly_compens_gross"] = this.emp_data.monthly_compens_gross
        } else {
          this.emp_details["monthly_compens_gross"] = 0
        }

        if (this.emp_data.training_done !== null) {
          this.emp_details["training_done"] = this.emp_data.training_done
        } else {
          this.emp_details["training_done"] = 0
        }

        if (this.emp_data.promotion !== null) {
          this.emp_details["promotion"] = this.emp_data.promotion
        } else {
          this.emp_details["promotion"] = 0
        }

        if (this.emp_data.gem_performer !== null) {
          this.emp_details["gem_performer"] = this.emp_data.gem_performer
        } else {
          this.emp_details["gem_performer"] = 0
        }
        
        if (this.emp_data.star_performer !== null) {
          this.emp_details["star_performer"] = this.emp_data.star_performer
        } else {
          this.emp_details["star_performer"] = 0
        }

        if (this.emp_data.vari_comp !== null) {
          this.emp_details["vari_comp"] = this.emp_data.vari_comp
        } else {
          this.emp_details["vari_comp"] = 0
        }

        if (this.emp_data.annual_hike_percentage !== null) {
          this.emp_details["annual_hike_percentage"] = this.emp_data.annual_hike_percentage
        } else {
          this.emp_details["annual_hike_percentage"] = 0
        }

        if (this.emp_data.pip_act !== null) {
          this.emp_details["pip_act"] = this.emp_data.pip_act
        } else {
          this.emp_details["pip_act"] = 0
        }

        this.emp_details["marital_status"] = this.emp_data.marital_status
        this.emp_details["emp_qualif"] = this.emp_data.emp_qualif
        this.emp_details["repo_qualif"] = this.emp_data.repo_qualif
        this.emp_details["emp_repo_location"] = this.emp_data.emp_repo_location
        this.emp_details["emp_repo_depart"] = this.emp_data.emp_repo_depart
        this.emp_details["mother_tongue"] = this.emp_data.mother_tongue
        this.emp_details["state"] = this.emp_data.state
        this.emp_details["prev_q_perform1"] = this.emp_data.prev_q_perform1
        this.emp_details["prev_q_perform2"] = this.emp_data.prev_q_perform2
        this.emp_details["oprn_category"] = this.emp_data.oprn_category
        this.emp_details["disp_act"] = this.emp_data.disp_act

        this.childEvent.emit(this.emp_details)
      }
    })
  }

  ngOnDestroy(): void {
    //unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

  rerender(): void {
    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
      // Destroy the table first
      dtInstance.destroy();
      // Call the dtTrigger to rerender again
      this.dtTrigger.next();
    });
  }

  plot_roleTable() {
    let self = this;
    this.dtOptions = {
      data: this.emp_arr,
      columns: [{
        title: 'Employee Id',
        data: 'empid',
        className: "emp_Id"
      },
      {
        title: 'Name',
        data: 'empname',

      },
      {
        title: 'Grade',
        data: 'grade_name',
      },
      {
        title: 'Operational Category',
        data: 'oprn_category',
      }],
      rowCallback: (row: Node, data: any[] | Object, index: number) => {
        $('td', row).unbind('click');
        $('td', row).bind('click', () => {
          $(".text-danger").hide()
          this.model.emp_id = data["empid"]
          this.getEmployeeService(this.model)
        });
      }
    };
  }
}
