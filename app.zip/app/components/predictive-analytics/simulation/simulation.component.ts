import { Component, OnInit, ɵConsole } from '@angular/core';
import { PredictiveTabServiceService } from 'src/app/common/services/predictive-services/predictive-tab-service.service';
import * as _ from "lodash";
import { Message } from '@angular/compiler/src/i18n/i18n_ast';
import { Utils } from 'src/app/common/shared/utility';
declare var $: any

@Component({
  selector: 'app-simulation',
  templateUrl: './simulation.component.html',
  styleUrls: ['./simulation.component.css']
})
export class SimulationComponent implements OnInit {
  pred_quarter = ""
  model: any = {
    emp_age: 15,
    repo_age: 15,
    experience_in_current_role: 0,
    total_experience_in_mf: 0,
    repo_total_experience_in_mf: 0,
    repo_experience_in_current_role: 0,
    no_leaves_taken: 0,
    no_lang_known: 1,
    star_performer: 0,
    gem_performer: 0,
    promotion: 0,
    extension_of_probation: 0,
    training_done: 0,
    marital_status: "",
    emp_qualif: "",
    repo_qualif : "",
    emp_repo_location: "",
    emp_repo_depart: "",
    mother_tongue: "",
    state: "",
    prev_q_perform1: "",
    prev_q_perform2: "",
    disp_act: 0,
    pip_act : 0,
    oprn_category: "ENPC",
    vari_comp: 0,
    monthly_compens_gross: 5000,
    annual_hike_percentage: 0,
    contract: 0,
    repo_no_lang_known : 1
  };
  public childData: any;

  dur_mf: number = 0;
  ageList: any = [15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39,
    40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59,
    60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70];
  ageLabel: any = [15, 20, 25, 30, 35, 40, 45, 50, 55, 60, 65, 70];
  exp_curnt_role_list: any = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20];
  exp_curnt_role_label_list: any = [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20];
  totalExpList: any = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30];
  totalExpList_label: any = [0, 5, 10, 15, 20, 25, 30];
  langKnwList: any = [1, 2, 3, 4, 5];
  hikePerList: any = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39,
    40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59,
    60];
  hikePerLabel: any = [0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60]
  state_list: any = [];
  selected_language: any = [];
  state_data: any;
  simulate_res: any = {
    data: {},
  };

  limeChart_data_list: any ;
  marked: boolean = false;
  isChecked: boolean = false;

  constructor(private service: PredictiveTabServiceService) { }

  ngOnInit() {
    this.getStateLangData();
    this.pred_quarter = localStorage.getItem("pre_q_year")

    $(".form-check-box").prop("checked", false);

  }

  reset() {
    this.model.emp_age = 15;
    this.model.experience_in_current_role = 0;
    this.model.total_experience_in_mf = 0;
    this.model.no_leaves_taken = 0;
    this.model.no_lang_known = 1;
    this.model.star_performer = 0;
    this.model.gem_performer = 0;
    this.model.promotion = 0;
    this.model.extension_of_probation = 0;
    this.model.training_done = 0;
    this.model.marital_status = "";
    this.model.emp_qualif = "";
    this.model.repo_qualif  = "";
    this.model.emp_repo_location = "";
    this.model.emp_repo_depart = "";
    this.model.mother_tongue = "";
    this.model.state = "";
    this.model.prev_q_perform1 = "";
    this.model.prev_q_perform2 = "";
    this.model.repo_total_experience_in_mf = 0;
    this.model.repo_experience_in_current_role = 0;
    this.model.repo_age = 0;
    this.model.disp_act = 0;
    this.model.pip_act  = 0;
    this.model.oprn_category = "ENPC";
    this.model.vari_comp = 0;
    this.model.monthly_compens_gross = 5000
    this.model.annual_hike_percentage = 0
    this.model.contract = 0;
    this.model.repo_no_lang_known = 1;
  }


  getStateLangData() {
    this.service.state_list().subscribe((data: any) => {
      this.state_data = data
      this.state_list = Object.keys(this.state_data.data);
      this.selected_language = Object.values(this.state_data.data);
      this.selected_language = _.unionBy(this.selected_language);
    })
  }

  toggleVisibility(e) {
    this.marked = e.target.checked;
    if (this.marked === true) {
      this.model.prev_q_perform1 = ""
      this.model.prev_q_perform2 = ""
    }
  }

  toggleVisibility_repo(e) {
    this.isChecked = e.target.checked;
    if (this.isChecked === true) {
      this.model.repo_total_experience_in_mf = 0;
      this.model.repo_experience_in_current_role = 0;
      this.model.repo_age = 0;
      this.model.repo_qualif  = "";
      this.model.repo_no_lang_known = 1
    }
  }

  simulateSubmit(value) {
    let data_list = []
    var newModel = Object.assign({}, this.model);
    newModel.experience_in_current_role = (this.model.experience_in_current_role) * 12;
    newModel.total_experience_in_mf = (this.model.total_experience_in_mf) * 12;
    newModel.repo_experience_in_current_role = (this.model.repo_experience_in_current_role) * 12;
    newModel.repo_total_experience_in_mf = (this.model.repo_total_experience_in_mf) * 12;

    this.service.simulation_data(newModel).subscribe((res: any) => {
      //Lime chart response 

      this.simulate_res["input_prediction"] = res["input_prediction"];

      // predictive data response 

      this.simulate_res["data"].marital_status_Single = res["data"].marital_status_Single;
      this.simulate_res["data"].marital_status_Married = res["data"].marital_status_Married;
      this.simulate_res["data"].emp_qualif_cat_post_grad = res["data"].emp_qualif_cat_post_grad;
      this.simulate_res["data"].emp_qualif_cat_under_grad = res["data"].emp_qualif_cat_under_grad;
      this.simulate_res["data"].emp_qualif_cat_grad = res["data"].emp_qualif_cat_grad;
      this.simulate_res["data"].location_emp_rep_same = res["data"].location_emp_rep_same;
      this.simulate_res["data"].location_emp_rep_different = res["data"].location_emp_rep_different;
      this.simulate_res["data"].department_emp_rep_same = res["data"].department_emp_rep_same;
      this.simulate_res["data"].department_emp_rep_different = res["data"].department_emp_rep_different;
      this.simulate_res["data"].emp_state_lang_same = res["data"].emp_state_lang_same;
      this.simulate_res["data"].emp_state_lang_different = res["data"].emp_state_lang_different;
      this.simulate_res["data"].total_experience_months_in_mf = (res["data"].total_experience_months_in_mf / 12).toFixed(1);
      this.simulate_res["data"].experience_in_current_role_in_months = (res["data"].experience_in_current_role_in_months / 12).toFixed(1);
      this.simulate_res["data"].extension_of_probation = res["data"].extension_of_probation;
      this.simulate_res["data"].promotion = res["data"].promotion;
      this.simulate_res["data"].training_done = res["data"].training_done;
      this.simulate_res["data"].emp_age = res["data"].emp_age;
      this.simulate_res["data"].gem_performer = res["data"].gem_performer;
      this.simulate_res["data"].star_performer = res["data"].star_perform;
      this.simulate_res["data"].no_leaves_taken = res["data"].no_leaves_taken;
      this.simulate_res["data"].emp_lang_count = res["data"].emp_lang_count;
      this.simulate_res["data"].performance_category_2018_q2_A = res["data"].performance_category_2018_q2_A;
      this.simulate_res["data"].performance_category_2018_q2_B = res["data"].performance_category_2018_q2_B;
      this.simulate_res["data"].performance_category_2018_q2_C = res["data"].performance_category_2018_q2_C;
      this.simulate_res["data"].performance_category_2018_q2_D = res["data"].performance_category_2018_q2_D;
      this.simulate_res["data"].performance_category_2018_q3_A = res["data"].performance_category_2018_q3_A;
      this.simulate_res["data"].performance_category_2018_q3_B = res["data"].performance_category_2018_q3_B;
      this.simulate_res["data"].performance_category_2018_q3_C = res["data"].performance_category_2018_q3_C;
      this.simulate_res["data"].performance_category_2018_q3_D = res["data"].performance_category_2018_q3_D;
      this.simulate_res["data"].annual_hike_percentage = res["data"].annual_hike_percentage;
      this.simulate_res["data"].repo_lang_count = res["data"].repo_lang_count;
      this.simulate_res["data"].repo_office_age = res["data"].repo_office_age;
      this.simulate_res["data"].repo_qualif_cat_post_grad = res["data"].repo_qualif_cat_post_grad;
      this.simulate_res["data"].repo_qualif_cat_under_grad = res["data"].repo_qualif_cat_under_grad;
      this.simulate_res["data"].repo_qualif_cat_grad = res["data"].repo_qualif_cat_grad;
      this.simulate_res["data"].reporting_officer_experience_in_current_role_in_months = (res["data"].reporting_officer_experience_in_current_role_in_months / 12).toFixed(1);
      this.simulate_res["data"].reporting_officer_total_experience_months_in_mf = (res["data"].reporting_officer_total_experience_months_in_mf / 12).toFixed(1);
      this.simulate_res["data"].variable = res["data"].variable;
      this.simulate_res["data"].contract_prev_q = res["data"].contract_prev_q;      
      this.simulate_res["data"].dic_2018_q3_0 = res["data"].dic_2018_q3_0;
      this.simulate_res["data"].dic_2018_q3_yes = res["data"].dic_2018_q3_yes;
      this.simulate_res["data"].monthly_gross = res["data"].monthly_gross;
      this.simulate_res["data"].pip_2018_q3 = res["data"].pip_2018_q3;
      this.simulate_res["data"].oprn_category_EHBC = res["data"].oprn_category_EHBC;
      this.simulate_res["data"].oprn_category_ENPC = res["data"].oprn_category_ENPC;
      this.simulate_res["data"].oprn_category_ESBC = res["data"].oprn_category_ESBC;

      
      this.simulate_res["message"] = res["message"];
    })

    // lime graph api
    this.service.lime_explainer_graph_data(newModel).subscribe((res: any) => {
      let self = this
      self.limeChart_data_list = res.data
    })
  }

  dom_to_img(event, chart_name) {
    Utils.dom_to_img(event.target, chart_name);
  }
}
