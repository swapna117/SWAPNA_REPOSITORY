import { Component, OnInit } from '@angular/core';
import { ModelHealthService } from 'src/app/common/services/predictive-services/model-health.service';
import { Utils } from 'src/app/common/shared/utility';


@Component({
  selector: 'app-model-health',
  templateUrl: './model-health.component.html',
  styleUrls: ['./model-health.component.css']
})
export class ModelHealthComponent implements OnInit {


  training_rows: number;
  training_accuracy: any;
  test_rows: number;
  test_accuracy: any;
  recall: any;
  precision: any;
  accuracy: any;
  f_score: any;

  trained_year_quarter = ""
  prediction_year_quarter = ""

  constructor(private api: ModelHealthService) { }

  ngOnInit() {
    this.insert_model_health_data()
    this.get_model_health_data()
  }

  insert_model_health_data(){
    this.api.insert_model_health_data().subscribe((res: any) => {
      
    })
  }

  get_model_health_data() {
    let self = this
    this.api.get_model_health_data().subscribe((res: any) => {

      self.training_rows = res.data.training_rows
      self.training_accuracy = (res.data.train_accuracy * 100).toFixed(2)
      self.test_rows = res.data.testing_rows
      self.test_accuracy = (res.data.test_accuracy * 100).toFixed(2)
      self.recall = (res.data.test_recall * 100).toFixed(2)
      self.precision = (res.data.test_precision * 100).toFixed(2)
      self.accuracy = (res.data.auc_test * 100).toFixed(2)
      self.f_score = (res.data.test_f1 * 100).toFixed(2)
      self.trained_year_quarter = (res.data.train_quarter.toString() + " " + res.data.train_year).replace(/[&\/\\#+()$~%.'":*?<>{}]/g, '');
      self.prediction_year_quarter = res.data.pred_quarter + " " + res.data.pred_year
      localStorage.setItem("pre_q_year", self.prediction_year_quarter)
    })
  }

  dom_to_img(event, chart_name) {
    Utils.dom_to_img(event.target, chart_name);
  }
}
