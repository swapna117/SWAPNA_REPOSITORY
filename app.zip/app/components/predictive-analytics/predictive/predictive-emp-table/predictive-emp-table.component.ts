import { Component, OnInit, ViewChild, OnDestroy, Injectable, Input } from '@angular/core';
import { DataTableDirective } from 'angular-datatables';
import { HttpClient } from '@angular/common/http';
import { Subject } from 'rxjs';
import { PredictiveTabServiceService } from 'src/app/common/services/predictive-services/predictive-tab-service.service';
import { CsvDownloaderService } from 'src/app/common/services/csv-downloader.service';

@Component({
  selector: 'app-predictive-emp-table',
  templateUrl: './predictive-emp-table.component.html',
  styleUrls: ['./predictive-emp-table.component.css']
})

@Injectable({
  providedIn: 'root'
})

export class PredictiveEmpTableComponent implements OnInit {

  @Input() filter: any;
  @ViewChild(DataTableDirective)
  dtElement: DataTableDirective;
  dtOptions: any = {};
  dtTrigger: any = new Subject();
  data = [];
  emp_list: any = [];
  csv_data:any;
  table_filter: any = {};

  constructor(private api: PredictiveTabServiceService,private csv_object: CsvDownloaderService) { }

  ngOnInit() {
    this.plot_userTable()
    this.predictive_emp_data(this.filter)
  }

  ngOnChanges(changes): void{
    if (changes.filter.currentValue != undefined) {
      this.table_filter.limit = 10

      this.filter.limit = 10
      this.predictive_emp_data(this.filter)
    }
  }

  filterSubmit() {
    this.filter.limit = this.table_filter.limit
    this.predictive_emp_data(this.filter);
  }

  rerender(): void {
    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
      // Destroy the table first
      dtInstance.destroy();
      // Call the dtTrigger to rerender again
      this.dtTrigger.next();
    });
  }

  predictive_emp_data(filter) {
    filter = this.filter
    this.api.predictive_emp_list(filter).subscribe((res: any) => {
      this.csv_data = res["data"]
      this.emp_list.length = 0
      for (let value of res.data) {
        this.emp_list.push(value);
      }
      if (!this.dtElement.dtInstance) {

        this.dtTrigger.next();
      } else {
        this.rerender()
      };
    });
  }

  ngOnDestroy(): void {
    //unsubscribe the event
    this.dtTrigger.unsubscribe();
  }
  plot_userTable() {

    let self = this;
    this.dtOptions = {
      data: this.emp_list,
      columns: [
        {
          title: "Employee ID",
          data: "empid",
        },
        {
          title: 'Employee Name',
          data: 'empname',
        },
        {
          title: 'Oprn Category',
          data: 'oprn_cat',
        },
        {
          title: 'Predicted RBMI Percentage',
          data: 'predict_rbmi',
        },
        {
          title: 'Performance',
          data: 'performance_cat',
        }
      ],
    }
  }

  download($event) {
    this.csv_object.download_predictive_user_data($event, this.csv_data)
  }
}
