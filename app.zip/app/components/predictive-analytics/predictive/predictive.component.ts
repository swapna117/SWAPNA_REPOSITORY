import { Component, OnInit } from '@angular/core';
import { PredictiveTabServiceService } from 'src/app/common/services/predictive-services/predictive-tab-service.service';
import { Utils } from 'src/app/common/shared/utility';
import * as _ from 'lodash';
import { CsvDownloaderService } from 'src/app/common/services/csv-downloader.service';


@Component({
  selector: 'app-predictive',
  templateUrl: './predictive.component.html',
  styleUrls: ['./predictive.component.css']
})
export class PredictiveComponent implements OnInit {
  prediction_year_quarter: any = "";
  parameters_data: any;
  public childData: any = { high_perform_percent: "", low_perform_percent: "" };
  filters: any = {};
  percent_achivement: any = {};
  get_parameter_service_subscribe: any;
  tier_data: any;
  tier_percent_data: any;
  chart_height: any = 385;
  options: any = "true";
  barFilter: any = {}
  csv_percent_data = []
  csv_count_data = []
  serieClickEvent:any;

  constructor(private api: PredictiveTabServiceService,private csv_object: CsvDownloaderService) { };
  


  ngOnDestroy() {
    if (this.get_parameter_service_subscribe) {
      this.get_parameter_service_subscribe.unsubscribe()
    }
    this.serieClickEvent.unbind();
  }

  ngOnInit() {
    let self = this
  
    self.serieClickEvent = $('body').on('click', ".serie rect", function () {
      if ($(this).hasClass('active')) {

        $('.serie rect').removeClass('active blur');
      } else {
        $('.serie rect').removeClass('active blur');
        console.log('--predictive---')
        let el_class = $(this).parent().data('class');

        $('.serie.' + el_class).find('rect').addClass('active');
        $('.serie rect:not(.active)').addClass('blur');
      }
    });
  // 
    this.prediction_year_quarter = localStorage.getItem("pre_q_year")
    this.filters.oprn_cat_tree = ""
    this.filters.circle = ""
    this.filters.divisions = ""
    this.filters.area = ""
    this.filters.performence_category = ""

    this.filters.branch_name = ""
    this.pred_perfom_data("ss")
    this.tierPerformance(this.filters)
    this.fetch_parameters_data()
  }

  ngOnChanges() {
   
  }

  fetch_parameters_data() {
    let self = this
    this.get_parameter_service_subscribe = this.api.get_predictive_parameter_service(this.filters).subscribe((res: any, ) => {
      self.parameters_data = res.data
    });
  }

  pred_emp_temp(event){}

  temp_function(data) {
    let self = this
    this.filters = data
    
    this.tierPerformance(this.filters)
    this.get_parameter_service_subscribe = this.api.get_predictive_parameter_service(this.filters).subscribe((res: any, ) => {
      self.parameters_data = res.data
    }); 
    
  }

  pred_perfom_data(data) {
    this.percent_achivement["a"] = data.a;
    this.percent_achivement["b"] = data.b;
    this.percent_achivement["c"] = data.c;
    this.percent_achivement["d"] = data.d;
  }

  tierPerformance(filters) {
    
    this.api.get_pred_tier_data(filters).subscribe((res: any) => {
      this.csv_count_data["tier_data"] = res["count_data"]
      this.csv_percent_data["tier_data"] = res["percent_data"]
      let tier_list = [];
      let tier_percent_list = []
      // Data manipulation to plot stacked bar chart

      _.each(res.count_data, function (d) {
        let temp = Object.assign({}, d);
        temp.key = temp.tier;
        temp.total = temp.total_count;
        temp = _.omit(temp, ['tier', 'total_count']);
        tier_list.push(temp);
      })
      this.tier_data = tier_list

      _.each(res.percent_data, function (d) {
        let temp = Object.assign({}, d);
        temp.key = temp.tier;
        temp.total = temp.total_count;
        temp = _.omit(temp, ['tier', 'total_count']);
        tier_percent_list.push(temp);
      })
      this.tier_percent_data = tier_percent_list
    })
  }

  clickFilter(event) {
    
    let self = this
    $(".serie rect", function () {
      if ($(".serie rect").hasClass('active')) {
        var grade_obj = { "a_count": "A", "b_count": "B", "c_count": "C", "d_count": "D" }
        self.barFilter["performence_category"]= grade_obj[event]
        var temp_obj = {}
        temp_obj = Object.assign(temp_obj, self.filters)
        temp_obj = Object.assign(temp_obj, self.barFilter)
        self.filters = temp_obj
      }
      else {
        self.barFilter["performence_category"]= ""
        var temp_obj = {}
        temp_obj = Object.assign(temp_obj, self.filters)
        temp_obj = Object.assign(temp_obj, self.barFilter)
        self.filters = temp_obj
      }
      
    })
  }

  dom_to_img(event, chart_name) {
    Utils.dom_to_img(event.target, chart_name);
  }

  download($event, value_name, range_value, per_value, file_name, data) {
    var data:any
    if (per_value == "true") {
      data = this.csv_percent_data
    } else {
      data = this.csv_count_data
    }

    this.csv_object.download_csv($event, value_name,range_value,per_value,file_name,data)
  }

  
}
