import { Component, OnInit } from '@angular/core';
import { PredictiveTabServiceService } from 'src/app/common/services/predictive-services/predictive-tab-service.service';

@Component({
  selector: 'app-predictive-nav',
  templateUrl: './predictive-nav.component.html',
  styleUrls: ['./predictive-nav.component.css']
})
export class PredictiveNavComponent implements OnInit {

  constructor(private api:PredictiveTabServiceService) { 
   
  }

  ngOnInit() {
  }


  

}
