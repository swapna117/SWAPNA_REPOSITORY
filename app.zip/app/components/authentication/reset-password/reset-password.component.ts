import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/common/services/auth.service';
declare var $: any;

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {

  model: any = {};
  passwordType: string = 'password';
  passwordShow: boolean = false;
  iconType: string = "fa fa-eye"
  loginStatus: string = "";
  resetsuccess: string;

  constructor(private service: AuthService,
    private router: Router) { }

  ngOnInit() {

  }


  showPassword() {
    if (this.passwordShow) {
      this.passwordShow = false;
      this.passwordType = 'password';
      this.iconType = "fa fa-eye"
    } else {
      this.passwordShow = true;
      this.passwordType = 'text';
      this.iconType = "fa fa-eye-slash"

    }
  }


  resetPassword(form: any) {

    var token = localStorage.getItem('token')
    this.model.token = token;
    this.service.reset_password(this.model).subscribe((res: any) => {
      if (res.message == "Password Updated") {
        this.loginStatus = "Password updated successfully. Redirecting to the Login page.."
        form.reset();
        setTimeout(() => {
          this.router.navigate(['/']);
        }, 4000);
        localStorage.clear()
      }
    })
  }
}
