import { Component, OnInit, Injectable } from "@angular/core";
import { AuthService } from "src/app/common/services/auth.service";
import { Router } from "@angular/router";

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"]
})

@Injectable({
  providedIn: "root"
})

export class LoginComponent implements OnInit {
  model: any = {};
  public errors: any;
  loginStatus: any;
  passwordType: string = "password";
  passwordShow: boolean = false;
  iconType: string = "fa fa-eye";
  email_obj: any = {};
  loggedinUser: string;
  permissionArr: any = [];
  local_arr: any;
  local_token:any;

  constructor(private service: AuthService, private router: Router) { }

  ngOnInit() {
    this.local_arr = localStorage.getItem("permissions");
    
    if (localStorage.getItem("permissions") !== null) {
      this.permissionArr = this.local_arr.split(",");
    }
  }

  showPassword() {
    if (this.passwordShow) {
      this.passwordShow = false;
      this.passwordType = "password";
      this.iconType = "fa fa-eye";
    } else {
      this.passwordShow = true;
      this.passwordType = "text";
      this.iconType = "fa fa-eye-slash";
    }
  }

  onSubmit(data) {
    
    this.service.login_user(this.model).subscribe(
      (res: any) => {

        if (res.message !== "reset password") {
          var roleName = localStorage.setItem("roleName", res.message.role);
          var userid = localStorage.setItem("userid", res.message.id);

          var firstName = localStorage.setItem( "firstName",res.message.first_name);
          var lastName = localStorage.setItem("lastName", res.message.last_name);
          var email = localStorage.setItem("email", res.message.email);
        }
        var permissionArr = localStorage.setItem("permissions",res.message.permission_list);
        var permissionList = res.message.permission_list;
        var role = res.message.role;
        var message = res.message;

        if (message === "reset password") {
          var tokenVlue = localStorage.setItem("token", res.token);
          this.router.navigate(["reset_password"]);
        } else {
          var tokenVlue = localStorage.setItem("token", res.message.token);
          this.router.navigate(["/descriptive-analytics"]);
        }

        this.local_token = localStorage.getItem("token")
        if (this.local_token === "") {
          this.loginStatus = "*Password doesn't match. Please try again."
        }
      },

      err => {
        this.errors = err["error"];
        if (this.errors.message === "failed" && this.errors.error === "username doesn't exist") {
          this.loginStatus =
            "*Entered email id doesn't exist. Please enter your registered email id.";
        } else if ((this.errors.message === "failed" && this.errors.error === "enter correct password")) {
          this.loginStatus = "*Password doesn't match. Please try again.";
        } else if (this.errors.message === "Contact your admin") {
          this.loginStatus =
            "*Your account has been disabled. Please contact admin.";
        }
      }
    );
  }
}
