import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { AuthService } from 'src/app/common/services/auth.service';
import { ActivatedRoute } from '@angular/router';

declare var $: any;

@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.css']
})
export class CreateUserComponent implements OnInit {

  @Output() oncreationuser: EventEmitter<string> = new EventEmitter();

  email_change: boolean;
  model: any = {
    "user": {}
  }
  user_obj: any = {};
  role_data: any = [];
  loginStatus: string = "";
  registersuccess: string = "";
  permissionArr: any = [];
  local_arr: any;
  public errors: any;
  existfaild: any;
  roleHasError: boolean = true;

  constructor(private route: ActivatedRoute,
    private service: AuthService) { }

  ngOnInit() {

    this.local_arr = localStorage.getItem("permissions")
    this.permissionArr = this.local_arr.split(',')

    if (this.permissionArr.includes('Add User')) {
      this.service.getRoleData().subscribe((data: any) => {
        for (let value of data) {
          this.role_data.push(value.name);
        }
      });
    }

  }

  validateRole(value) {
    if (value === "default") {
      this.roleHasError = true;
    } else {
      this.roleHasError = false;
    }
  }

  onSignup(form: any) {
    let user_data: any = {}
    user_data["first_name"] = this.model['user'].first_name,
      user_data["last_name"] = this.model['user'].last_name,
      user_data["email"] = this.model['user'].email,
      user_data["username"] = this.model['user'].email,

      this.user_obj['user'] = user_data;
    this.user_obj['role'] = this.model['role']

    this.service.create_user(this.user_obj).subscribe((res: any) => {
      let tempObj = {};
      tempObj = res.data["user"];
      tempObj["role"] = res.data["role"];
      tempObj["is_active"] = true;

      if (res["message"] == "success") {
        this.registersuccess = "User registered successfully"
        $('.msg_display .text-success').text(this.registersuccess).show().fadeOut(3000);
        setTimeout(function () {
          $('.modal').modal('hide')
        }, 1500);

        this.oncreationuser.emit(res)
        form.reset()

        this.loginStatus = ""
      }
    },
      err => {
        this.errors = err["error"];
        if (this.errors["message"] == "email already exists") {
          this.existfaild = "*Email id already exists."
          $('.msg_display .text-danger').text(this.existfaild).show().fadeOut(6000)
        }
      }
    );
  }
}
