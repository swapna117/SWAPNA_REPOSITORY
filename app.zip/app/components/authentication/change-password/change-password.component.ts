import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/common/services/auth.service';
declare var $: any;

@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {

  model: any = {};
  oldPasswordType: string = 'password';
  newPasswordType: string = 'password';
  passwordShow: boolean = false;
  newIconType: string = "fa fa-eye";
  oldIconType: string = "fa fa-eye";
  changePwdCrt: string = "";
  changePwdwng: string = "";
  public errors: any;
  samePwd: any;

  constructor(private service: AuthService,
    private router: Router) { }

  ngOnInit() {

  }

  showOldPassword() {
    if (this.passwordShow) {
      this.passwordShow = false;
      this.oldPasswordType = 'password';
      this.oldIconType = "fa fa-eye"
    } else {
      this.passwordShow = true;
      this.oldPasswordType = 'text';
      this.oldIconType = "fa fa-eye-slash"
    }
  };

  showNewPassword() {
    if (this.passwordShow) {
      this.passwordShow = false;
      this.newPasswordType = 'password';
      this.newIconType = "fa fa-eye"
    } else {
      this.passwordShow = true;
      this.newPasswordType = 'text';
      this.newIconType = "fa fa-eye-slash"
    }
  };

  changePassword(form) {
    if (this.model.old_password === this.model.new_password) {
      this.samePwd = "*Old password and New password can't be same";
      $('.msg_display .text').text(this.samePwd).show().css({ "color": "#dc3545" });
    }
    else {
      this.service.change_password(this.model).subscribe((res) => {
        if (res["message"] == "Success.") {
          this.changePwdCrt = "Password Updated successfully";
          $('.msg_display .text').text(this.changePwdCrt).show().css({ "color": "#28a745" }).fadeOut(4000);
          form.reset()
          this.changePwdCrt = ""
        }
      },

        err => {
          this.errors = err
          if (this.errors === "Precondition Failed") {
            this.changePwdwng = "*Old password is Incorrect. Try again."
            $('.msg_display .text').text(this.changePwdwng).show().css({ "color": "#dc3545" });
            this.changePwdwng = ""
          }
        }
      );
    }
  }
}
