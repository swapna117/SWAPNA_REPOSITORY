import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { AuthService } from 'src/app/common/services/auth.service';
import { ActivatedRoute } from '@angular/router';
declare var $: any;

@Component({
  selector: 'app-create-role',
  templateUrl: './create-role.component.html',
  styleUrls: ['./create-role.component.css']
})
export class CreateRoleComponent implements OnInit {
  @Output() oncreationrole: EventEmitter<object> = new EventEmitter();

  model: any = {
    permission_list: []
  };
  dropdownSettingspermissions = {};
  permissionsList: any = [];
  selectedpermissions: any = [];
  roleStatus: any;
  roleSuccess: any;
  permissionArr: any = [];
  local_arr: any;
  errors: any;

  constructor(private service: AuthService,
    private route: ActivatedRoute) { }

  ngOnInit() {

    this.local_arr = localStorage.getItem("permissions")
    this.permissionArr = this.local_arr.split(',')
    this.onpermissionSelect()

    this.dropdownSettingspermissions = {
      singleSelection: false,
      text: "Select Permissions",
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: "roleDropdown multiSelectDropdown",
      primaryKey: "id",
      labelKey: "name",
      badgeShowLimit: 3,
    }
  }


  onpermissionSelect() {
    if (this.permissionArr.includes('Add Role')) {
      this.service.getPermissions().subscribe((data: any) => {
        for (let val of data) {
          this.permissionsList.push(val);
        }
      });
    }
  }

  createRole(form: any) {
    var roleObj = {
      permission_list: []
    }
    roleObj["name"] = this.model.name;
    for (let i of this.model.permission_list) {
      roleObj.permission_list.push(i.name)
    }

    this.service.createRole(roleObj).subscribe((res) => {
      let tempObj = {}
      tempObj["name"] = res["data"]["name"];
      tempObj["permission_list"] = res["data"]["permission_list"];
      tempObj["id"] = res["data"]["id"]
      var self = this
      if (res["message"] == "success") {
        this.roleSuccess = "*Role added successfully!"
        $('.msg_display .text-success').text(this.roleSuccess).show().fadeOut(4000);
        setTimeout(function () {
          $('.modal').modal('hide')
        }, 3000)
        this.oncreationrole.emit(res)
        form.reset()
      }
    },
      err => {
        this.errors = err["error"];
        if (this.errors.message === "failed") {
          this.roleStatus = "*Role already exists";
          $('.msg_display .text-danger').text(this.roleStatus).show().fadeOut(6000);
        }
      }
    );
  }
}
