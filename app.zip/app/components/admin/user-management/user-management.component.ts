import { Component, OnInit, ViewChild, OnDestroy, Injectable } from '@angular/core';
import { DataTableDirective } from 'angular-datatables';
import { HttpClient } from '@angular/common/http';
import { Subject } from 'rxjs';
import { ProjectServiceService } from 'src/app/common/services/project-service.service';
import { AuthService } from 'src/app/common/services/auth.service';
declare var $: any;

@Component({
  selector: 'app-user-management',
  templateUrl: './user-management.component.html',
  styleUrls: ['./user-management.component.css']
})

@Injectable({
  providedIn: 'root'
})

export class UserManagementComponent implements OnInit, OnDestroy {
  idex_value;

  UserDataTableData: any = [];
  editUserObj: any = {};
  role_data: any = [];
  updateSuccess: string = "";
  updateStatus: any;
  rowData: any = [];
  deleteSuccess: string;
  deleteStatus: string;
  role: any;
  permissionArr: any = [];
  local_arr: any;

  @ViewChild(DataTableDirective)
  dtElement: DataTableDirective;
  dtOptions: any = {};
  dtTrigger: any = new Subject();
  data = [];

  constructor(public httpClient: HttpClient,
    private authService: AuthService,
    private service: ProjectServiceService) { }


  ngOnInit() {
    this.local_arr = localStorage.getItem("permissions")
    this.permissionArr = this.local_arr.split(',')

    this.fetch_user_data()

    this.plot_userTable()

    this.role = localStorage.getItem("roleName")
  }

  fetch_user_data() {
    if (this.permissionArr.includes('Edit User')) {
      this.authService.getRoleData().subscribe((res: any, ) => {
        for (let value of res) {
          this.role_data.push(value.name);
        }
      });
    }
    this.service.user_list().subscribe((res: any) => {

      this.data = res;


      for (let i of this.data["data"]) {
        i.user['role'] = i.role;
        this.UserDataTableData.push(i.user);
      }
      this.dtTrigger.next();
    });
  }

  ngOnDestroy(): void {
    //unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

  rerender(): void {
    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
      // Destroy the table first
      dtInstance.destroy();
      // Call the dtTrigger to rerender again
      this.dtTrigger.next();
    });
  }

  //User list Datatble
  plot_userTable() {
    let self = this;
    this.dtOptions = {
      "scrollX": true,
      data: this.UserDataTableData,
      columns: [
        {
          title: 'Id',
          data: "id",
          width: '45px',
        }, {
          title: 'First Name',
          data: 'first_name',
          width: '100px',
        }, {
          title: 'Last Name',
          data: 'last_name',
          width: '100px',
        }, {
          title: 'Email',
          data: 'email',
          width: '200px',
        }, {
          title: 'Role',
          data: 'role',
          width: '100px',
        }, {
          title: 'Status',
          data: 'is_active',
          width: '80px',
          "render": function (flag, a, r) {
            let disabled = '';
            let checked = r.is_active ? 'checked' : '';

            if (self.permissionArr.includes("Change Status")) {
              disabled = ''
            } else {
              disabled = 'disabled'
            }

            if (r.role == "admin" || self.role == r.role) {
              disabled = 'disabled';
            }

            let btn = `<label class="switch toggle-status"><input type="checkbox" ${checked} ${disabled}>
                        <span class="slider round" title="Change Status"></span>
                      </label>`;
            return btn;
          }
        }, {
          title: 'Actions',
          className: 'control',
          width: '150px',
          "render": function (flag, a, r) {

            let disabled_delete = 'disabled';
            let edit_disabled = '';
            let reset_password = ''

            if (r.role == "admin" || localStorage.getItem("roleName") == r.role) {
              edit_disabled = 'disabled';
            }

            if (r.role == "admin" || localStorage.getItem("roleName") !== "admin") {
              reset_password = 'disabled'
            }

            if (r.role !== "admin" && localStorage.getItem("roleName") !== r.role) {
              if (self.permissionArr.includes("Edit User")) {
                edit_disabled = ''
              } else {
                edit_disabled = 'disabled';
              }

              if (self.permissionArr.includes("Edit User")) {
                edit_disabled = ''
              } else {
                edit_disabled = 'disabled';
              }
            }


            let btn = `<button class="btn btn-edit" ${edit_disabled} title="Edit User">
                        <i class="fa fa-pencil"></i>
                      </button>
                      <button class="btn btn-delete" ${disabled_delete} title="Delete User" style = "cursor: not-allowed";>
                        <i class="fa fa-trash"></i>
                      </button>
                      <button class="btn btn-refresh" ${reset_password}  title="Set Default Password">
                        <i class="fa fa-unlock-alt"></i>
                      </button>`;
            return btn;
          }
        }
      ],

      // Function for inline click
      rowCallback: (row: Node, data: any[] | Object, index: number) => {

        $('td label.toggle-status', row).unbind('change');
        $('td label.toggle-status', row).bind('change', (event) => {
          this.toggleStatus(data, event.target.checked);
        });

        $('td button.btn-edit', row).unbind('click');
        $('td button.btn-edit', row).bind('click', () => {
          this.openEditUserModal(data);
        });

        $('td button.btn-delete', row).unbind('click');
        $('td button.btn-delete', row).bind('click', () => {
          this.rowData = data
          this.displayDelete();
        });

        $('td button.btn-refresh', row).unbind('click');
        $('td button.btn-refresh', row).bind('click', () => {
          this.rowData = data
          this.displayReset();
        });

        return row;
      }
    }
  }

  displayReset() {
    $("#default_confirm").modal("show")
  }


  displayDelete() {
    $("#delete_confirm").modal("show")
  }

  // Toggle status handler
  toggleStatus(data, isActive) {
    let params: any = {};
    params.user_id = data.id;
    params.is_active = isActive;
    this.service.toggleUserActivation(params).subscribe(res => { });
  }

  // Open edit user modal
  openEditUserModal(data: any) {
    this.editUserObj = $.extend({}, data);
    $('#editUserModal').modal('show');
  }

  // User Detail Edit Submit Handler
  editUserSubmitHandler(formData) {
    let userObj: any = { user: {} };
    userObj.role = formData.role;
    userObj.user.user_id = formData.user_id;
    userObj.user.first_name = formData.first_name;
    userObj.user.last_name = formData.last_name;

    this.service.userEdit(userObj).subscribe((res: any, ) => {
      let idx = this.UserDataTableData.findIndex(x => x.id === formData.user_id);
      let obj: any = this.UserDataTableData[idx];
      obj["first_name"] = res.data.user.first_name;
      obj["last_name"] = res.data.user.last_name;
      obj["role"] = res.data.role;
      this.rerender();
      if (res["message"] == "success") {
        this.updateSuccess = "updated successfully"
        $('.msg_display .text-success').text(this.updateSuccess).show().fadeOut(3000);
        setTimeout(function () {
          $('.modal').modal('hide')
        }, 1000);
        this.updateStatus = ""
      }
    })
  }

  // Delete User
  deleteUser() {
    let userId = this.rowData.id;

    this.service.delete_user(userId).subscribe((res: any, ) => {
      let idx = this.UserDataTableData.findIndex(x => x.id === userId);
      this.UserDataTableData.splice(idx, 1);
      this.rerender();
      if (res.message === "success") {
        this.deleteSuccess = "User deleted successfully!."
        $('.msg_delete .text-delete').text(this.deleteSuccess).show().fadeOut(4000);
        setTimeout(function () {
          $('.modal').modal('hide')
        }, 2000);
        this.deleteStatus = ""
      }
    });
  }


  set_default() {
    let userId = this.rowData.id;
    this.service.set_default_password(userId).subscribe((res: any, ) => {
      if (res["message"] == "success") {
        this.deleteSuccess = "Password set to default."
        $('.msg_reset .text-reset').text(this.deleteSuccess).show().fadeOut(4000);
        setTimeout(function () {
          $('.modal').modal('hide')
        }, 2000);
        this.deleteStatus = ""
      }
    });
  }
  
  appendnewuser(event) {
    this.UserDataTableData.push(event["data"]["user"]);
    this.rerender()
  }
}
