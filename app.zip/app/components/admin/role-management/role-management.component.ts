import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { DataTableDirective } from 'angular-datatables';
import { HttpClient } from '@angular/common/http';
import { Subject } from 'rxjs';
import { ProjectServiceService } from 'src/app/common/services/project-service.service';
declare var $: any;


import * as _ from "lodash";
import { AuthService } from 'src/app/common/services/auth.service';
import { JsonPipe } from '@angular/common';

@Component({
  selector: 'app-role-management',
  templateUrl: './role-management.component.html',
  styleUrls: ['./role-management.component.css']
})
export class RoleManagementComponent implements OnInit, OnDestroy {
  idex_value;
  model: any = {};
  rolesList: any = [];
  role_permission: any = [];
  currObj: any = {};
  dropdownSettingspermissions: any;
  individualRole: any;
  rowData: any = [];
  permissionsList: any = [];
  updateSuccess: string;
  updateStatus: string;
  deleteSuccess: string;
  deleteStatus: string;
  role: any;
  permissionArr: any = [];
  local_arr: any;

  @ViewChild(DataTableDirective)
  dtElement: DataTableDirective;
  dtOptions: DataTables.Settings = {};
  dtTrigger: any = new Subject();

  constructor(public httpClient: HttpClient,
    private authService: AuthService,
    private service: ProjectServiceService, ) { }


  ngOnInit() {
    this.local_arr = localStorage.getItem("permissions")
    this.permissionArr = this.local_arr.split(',')

    this.role = localStorage.getItem("roleName");
    this.plot_roleTable();
    this.fetchRolePermissionData();
    this.onpermissionSelect();

    this.dropdownSettingspermissions = {
      singleSelection: false,
      text: "Select Permissions",
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      enableSearchFilter: true,
      classes: "roleEditClass custom-class-example",
      primaryKey: "id",
      labelKey: "name",
      badgeShowLimit: 4,
    }
  }


  fetchRolePermissionData() {
    this.service.getPermissionList().subscribe((data: any) => {
      console.log(data);
      
      for (let val of data.result) {
        this.role_permission.push(val)
      }
      this.dtTrigger.next();
    });
  }

  onpermissionSelect() {
    if (this.permissionArr.includes('Edit Role')) {
      this.authService.getPermissions().subscribe((data: any) => {

        for (let val of data) {
          this.permissionsList.push(val);
        }
      });
    }
  }

  ngOnDestroy(): void {
    //unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

  rerender(): void {
    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
      // Destroy the table first
      dtInstance.destroy();
      // Call the dtTrigger to rerender again
      this.dtTrigger.next();
    });
  }


  plot_roleTable() {
    let self = this;
    this.dtOptions = {
      "scrollX": true,
      data: this.role_permission,
      columns: [{
        title: 'Id',
        data: 'id',
        width: '45px',
      },
      {
        title: 'Role',
        data: 'name',
        width: '100px',
      },
      {
        title: 'Permissions',
        data: 'permission_list',
        width: '700px',
      }, {
        title: 'Action',
        className: 'control',
        width: '100px',
        "render": function (flag, a, r) {
          let edit_disabled = '',
            delete_disabled = '';
          if (r.name === "admin" || localStorage.getItem("roleName") == r.name) {
            edit_disabled = 'disabled';
            delete_disabled = 'disabled';
          }

          if (r.name !== "admin" && localStorage.getItem("roleName") !== r.name) {
            if (self.permissionArr.includes("Edit Role")) {
              edit_disabled = ''
            } else {
              edit_disabled = 'disabled';
            }

            if (self.permissionArr.includes("Delete Role")) {
              delete_disabled = ''
            } else {
              delete_disabled = 'disabled';
            }
          }

          let btn = `<button class="btn btn-edit" ${edit_disabled} title="Edit Role">
                      <i class="fa fa-pencil"></i>
                      </button>
                      <button class="btn btn-delete"  ${delete_disabled} title="Delete Role">
                      <i class="fa fa-trash"></i>
                      </button>`

          return btn;
        }
      }],

      // Function for inline click
      rowCallback: (row: Node, data: any[] | Object, index: number) => {
        const self = this;
        $('td button.btn-edit', row).unbind('click');
        $('td button.btn-edit', row).bind('click', () => {

          this.editRole(data);
        });

        $('td button.btn-delete', row).unbind('click');
        $('td button.btn-delete', row).bind('click', () => {
          this.rowData = data

          this.displayDelete();
        });
        return row;
      }
    };
  }


  displayDelete() {
    $("#delete_confirm").modal("show")
  }

  // Edit role
  editRole(data) {
    this.individualRole = data;
    let selectedList = _.filter(this.permissionsList, function (d) {
      return _.includes(data.permission_list, d.name);
    })
    $('#role_edit_modal').modal('show');
    this.currObj = {
      role: data.name,
      permission_list: selectedList
    }
  }

  editRoleSubmit(formData) {
    formData["permission_list"] = _.map(formData.permission_list, function (d) {
      return d.name;
    })
    let roleObj = {};
    roleObj["id"] = this.individualRole.id;
    roleObj["actulaRoleObj"] = formData;

    this.service.userRoleEdit(roleObj).subscribe((res: any) => {
      let idx = this.role_permission.findIndex(x => x.id === roleObj["id"]);
      let obj: any = this.role_permission[idx];
      obj["role"] = res.data.role;
      obj["permission_list"] = res.data.permission_list;
      this.rerender();
      if (res["message"] == "success") {
        this.updateSuccess = "updated successfully"
        $('.msg_display .text-edit').text(this.updateSuccess).show().fadeOut(3000);
        setTimeout(function () {
          $('.modal').modal('hide')
        }, 1500);
        this.updateStatus = ""
      }
    });
  }


  // Delete role
  deleteRole() {
    let roleIdObj = {};

    roleIdObj["role_id"] = this.rowData.id
    this.service.delete_role(roleIdObj).subscribe((res: any) => {
      let idx = this.role_permission.findIndex(x => x.id === roleIdObj["role_id"]);
      this.role_permission.splice(idx, 1);
      this.rerender();
      if (res.message === "success") {
        this.deleteSuccess = "Role deleted successfully."
        $('.msg_delete .text-delete').text(this.deleteSuccess).show().fadeOut(3000);
        setTimeout(function () {
          $('.modal').modal('hide')
        }, 1500);
        this.deleteStatus = ""
      }
    });
  }


  appendnewrole(event) {
    this.role_permission.push(event["data"]);
    this.rerender()
  }
}
