import { Component, OnInit, Input, OnChanges, ViewChild, ElementRef } from '@angular/core';
import { ProjectServiceService } from 'src/app/common/services/project-service.service';
import { Subject } from 'rxjs';
import { DataTableDirective } from 'angular-datatables';
import { CsvDownloaderService } from 'src/app/common/services/csv-downloader.service';
declare var $: any;
import * as _ from "lodash";
import { Key } from 'protractor';

@Component({
  selector: 'app-top-managers-table',
  templateUrl: './top-managers-table.component.html',
  styleUrls: ['./top-managers-table.component.css']
})
export class TopManagersTableComponent implements OnInit, OnChanges {

  @ViewChild(DataTableDirective)
  dtElement: DataTableDirective;
  dtOptions: any = {};
  dtTrigger: any = new Subject();

  @Input() globalFilter: any;
  @Input() tree_map_filter_data: any;
  csv_data: any
  deptList = []
  currObj: any = {};
  dropdownSettings: {}
  private currElement: HTMLElement;
  private htmlElement: HTMLElement;

  filters: any;
  top_manager_data: any = [];
  selectedItems: any;
  rowData: any = [];
  filterData = {}
  table_filter: any = {};

  a_count_array: any = [];
  b_count_array: any = [];
  c_count_array: any = [];
  d_count_array: any = [];

  performerData: any = [];

  @ViewChild('chartContainer') element: ElementRef;

  constructor(private api: ProjectServiceService, private csv_object: CsvDownloaderService, private elRef: ElementRef) {
    this.currElement = this.elRef.nativeElement;
  }

  dept_list = [];
  quarterList = ["Q1", "Q2", "Q3", "Q4"];

  ngOnInit() {
    this.plot_userTable();

    this.dropdownSettings = {
      text: "Please Select Department",
      selectAllText: "Select All",
      unSelectAllText: "Select All",
      classes: "top-manager manager-class",
      badgeShowLimit: 1

    };
  }

  ngOnChanges(changes): void {
    if (changes.tree_map_filter_data.currentValue != undefined) {

      this.table_filter.limit = 10

      this.tree_map_filter_data.limit = 10

      this.fetch_top_manager_Data(this.tree_map_filter_data);
    }
  }

  ngOnDestroy(): void {
    this.dtTrigger.unsubscribe();
  }
  rerender(): void {
    this.dtElement.dtInstance.then((dtInstance: DataTables.Api) => {
      dtInstance.destroy();
      this.dtTrigger.next();
    });
  }

  table_filter_change(limit) {
    this.fetch_top_manager_Data(this.globalFilter);
  }

  filterSubmit() {
    this.tree_map_filter_data.limit = this.table_filter.limit
    this.fetch_top_manager_Data(this.tree_map_filter_data);
  }

  fetch_top_manager_Data(data) {
    this.api.top_manager_data(data).subscribe(res => {
      this.csv_data = res["data"]["performer_by_manager"]
      this.top_manager_data.length = 0
      for (let i of res["data"]["performer_by_manager"]) {
        this.top_manager_data.push(i)
      }

      if (!this.dtElement.dtInstance) {

        this.dtTrigger.next();
      } else {
        this.rerender()
      };
    });
  }


  plot_userTable() {

    let self = this;
    this.dtOptions = {
      data: this.top_manager_data,
      columns: [
        {
          title: "Employee ID",
          data: "empid",
        }, {
          title: 'Employee Name',
          data: 'empname',
        }, {
          title: 'Oprn Category',
          data: 'oprn_category',
        },
        {
          title: 'Quarter',
          data: 'quarter_name'
        },
        {
          title: 'RBMI Percentage',
          data: 'rbmi',
        },
        {
          title: 'Performance',
          data: 'performance_category',
        }
      ],
    }
  }


  empDataBasedManager(data) {

    let self = this

    let temp = this.filterData["reporting_officer_sap_code"]

    self.filterData["oprn_category"] = self.tree_map_filter_data.oprn_category;
    self.filterData["quarter"] = self.tree_map_filter_data.quarter;
    self.filterData["year"] = self.tree_map_filter_data.year;
    self.filterData["circle"] = self.tree_map_filter_data.circle;
    self.filterData["divisions"] = self.tree_map_filter_data.divisions;
    self.filterData["branch"] = self.tree_map_filter_data.branch;
    self.filterData["area"] = self.tree_map_filter_data.area;
    self.filterData["reporting_office_name"] = data.reporting_office_name;
    self.filterData["reporting_officer_sap_code"] = data.reporting_officer_sap_code;

    if (temp !== this.filterData["reporting_officer_sap_code"]) {
      this.a_count_array = [];
      this.b_count_array = [];
      this.c_count_array = [];
      this.d_count_array = [];

      self.api.emp_detail_from_manager(self.filterData).subscribe((res: any) => {

        for (let i of res.data) {
          let a_Obj = {};
          let b_Obj = {};
          let c_Obj = {};
          let d_Obj = {};

          if (i.a_count === 1) {
            a_Obj["empid"] = i.empid;
            a_Obj["empname"] = i.empname;
            this.a_count_array.push(a_Obj)
          }

          if (i.b_count === 1) {
            b_Obj["empid"] = i.empid;
            b_Obj["empname"] = i.empname;
            this.b_count_array.push(b_Obj)
          }

          if (i.c_count === 1) {
            c_Obj["empid"] = i.empid;
            c_Obj["empname"] = i.empname;
            this.c_count_array.push(c_Obj)
          }

          if (i.d_count === 1) {
            d_Obj["empid"] = i.empid;
            d_Obj["empname"] = i.empname;
            this.d_count_array.push(d_Obj)
          }
        };

      });
    }
  }

  get_a_count(data) {
    let performerData = [];

    this.empDataBasedManager(data);
    this.performerData = this.a_count_array
    $("#performer").modal("show")
  }

  get_b_count(data) {
    let performerData = [];
    this.empDataBasedManager(data);
    this.performerData = this.b_count_array
    $("#performer").modal("show")
  }

  get_c_count(data) {
    let performerData = [];
    this.empDataBasedManager(data);
    this.performerData = this.c_count_array
    $("#performer").modal("show")
  }

  get_d_count(data) {
    let performerData = [];
    this.empDataBasedManager(data);
    this.performerData = this.d_count_array
    $("#performer").modal("show")
  }

  download($event) {
    this.csv_object.download_top_managers($event, this.csv_data)
  }
}