import { Component, OnInit } from "@angular/core";
import { ProjectServiceService } from "../../common/services/project-service.service";
import * as _ from 'lodash';

import * as d3 from 'd3';
import { EventEmitter } from "protractor";
import { Utils} from 'src/app/common/shared/utility';
import { CsvDownloaderService } from "src/app/common/services/csv-downloader.service";

@Component({
  selector: "app-dashboard",
  templateUrl: "./dashboard.component.html",
  styleUrls: ["./dashboard.component.css"]
})

export class DashboardComponent implements OnInit {
  temp_department = ""
  csv_percent_data: any = {}
  options: any = "true";
  optionsKpi: any = "true"
  itemList = [];
  tree_map_chartData: any;
  selectedItems = [];
  settings = {};
  tree_map_filter: any = {}
  yearData = [];
  qualrter_list = ["Q1", "Q2", "Q3", "Q4"]
  csv_data: any = {}
  temp_object_exp_year: any = {}
  temp_object_comensation: any = {}
  marked: boolean = false;
  check: boolean = false;
  quarterList: any;
  temp_object_exp_month: any = {};
  selectedQuarterList: any;
  allData: any;
  performers: any;
  top_manager_table_filter;
  bothPerformers: any;
  d_month_performer: any = [];
  a_month_performer: any = [];
  b_month_performer: any = [];
  c_month_performer: any = [];
  tree_map_data: any;
  filterValue: any = {};
  globalFilter;
  total_achievement: any;
  current_role_month_exp = [];
  chartData: any;
  twAreaChartData: any;
  total_count = 0
  age_graph_data = []
  temp_object_age: any = {}
  temp_object: any = {}
  age_by_range = []
  leave_by_range = []
  compensation_by_range = []
  compensation_range = []
  age_data;
  leave_data;
  gradeData: any
  langData: any
  OprData: any
  rewdData: any
  trainData: any
  temp_asc_dict: any = {}
  age_data_performance: any;
  leave_data_performance: any
  global_range_data: any;
  compensation_data_performence: any;
  tree_map_flatData: any = {}
  tier_data: any
  tier_percent_data: any
  rewdDataPercent: any
  gradeDataPercent: any
  OprDataPercent: any
  langDataPercent: any
  age_data_percent: any
  leave_data_percent: any
  compensation_data: any
  compensation_percent
  trainDataPercent: any
  age_subscribe: any;
  leave_subscribe: any;
  month_range_subscribe: any;
  exp_range_subscribe: any;
  grade_subscribe: any;
  lang_subscribe: any;
  opr_subscribe: any;
  pip_subscribe: any;
  dic_subscribe: any;
  star_subscribe: any;
  gem_subscribe: any;
  training_subscribe: any;
  year_bu_subscribe: any;
  achievementData_subscribe: any;
  getFilterData_subscribe: any;
  achievementsChart_subscribe: any;
  current_role_exp = [];
  exp_data_performance: any;
  exp_data_performance_percent: any;
  exp_month_data: any;
  exp_month_data_percent: any;
  pip_data: any;
  pip_percent: any;
  dic_data: any;
  dic_percent: any;

  current_exp_data: any;
  current_month_exp_data: any;
  insightres: any = "";
  insighters_data: any = [];

  barFilter: any = {}
  chart_height: any = 430

  serieClickEvent: any;

  constructor(private api: ProjectServiceService, private csv_object: CsvDownloaderService) { }

  ngOnInit() {
    this.getYearBuData();
    this.quarterList = [
      {
        id: 0,
        itemName: "Q1"
      },
      {
        id: 1,
        itemName: "Q2"
      },
      {
        id: 2,
        itemName: "Q3"
      },
      {
        id: 3,
        itemName: "Q4"
      }
    ];
    this.selectedQuarterList = [...this.quarterList];
    this.settings = {
      text: "Please Select",
      selectAllText: "Select All",
      unSelectAllText: "Select All",
      classes: "myclass custom-class",
      badgeShowLimit: 1
    };
    let self = this

    self.serieClickEvent = $('body').on('click', ".serie rect", function () {
      if ($(this).hasClass('active')) {
        

        $('.serie rect').removeClass('active blur');
      } else {
        $('.serie rect').removeClass('active blur');

        let el_class = $(this).parent().data('class');
        

        $('.serie.' + el_class).find('rect').addClass('active');
      
        $('.serie rect:not(.active)').addClass('blur');
      }
    });
  }

  ngOnDestroy() {
    if (this.age_subscribe) {
      this.age_subscribe.unsubscribe();
    }
    if (this.leave_subscribe) {

      this.leave_subscribe.unsubscribe();
    }
    if (this.month_range_subscribe) {
      this.month_range_subscribe.unsubscribe();
    }
    if (this.exp_range_subscribe) {
      this.exp_range_subscribe.unsubscribe();
    }
    if (this.grade_subscribe) {

      this.grade_subscribe.unsubscribe();
    }
    if (this.lang_subscribe) {

      this.lang_subscribe.unsubscribe();
    }

    if (this.opr_subscribe) {
      this.opr_subscribe.unsubscribe();
    }
    if (this.pip_subscribe) {
      this.pip_subscribe.unsubscribe();
    }
    if (this.dic_subscribe) {
      this.dic_subscribe.unsubscribe();
    }
    if (this.star_subscribe) {
      this.star_subscribe.unsubscribe();

    }
    if (this.gem_subscribe) {

      this.gem_subscribe.unsubscribe();

    }
    if (this.training_subscribe) {
      this.training_subscribe.unsubscribe();

    }
    if (this.year_bu_subscribe) {
      this.year_bu_subscribe.unsubscribe();
    }


    if (this.achievementData_subscribe) {
      this.achievementData_subscribe.unsubscribe();

    }
    if (this.getFilterData_subscribe) {
      this.getFilterData_subscribe.unsubscribe();
    }

    if (this.achievementsChart_subscribe) {
      this.achievementsChart_subscribe.unsubscribe();

    }
    // document.getElementsByClassName(".serie rect").removeEventListener("mousemove", myFunction);
    // $(".serie rect").off('click');
    this.serieClickEvent.unbind();
  }

  toggleVisibility(e) {
    this.marked = e.target.checked;
  }

  toggleVisibility1(e) {
    this.check = e.target.checked;
  }

  getGlobalFilters() {
    return {
      "oprn_category": this.filterValue.oprn_category,
      "quarter": this.filterValue.quarter,
      "year": this.filterValue.year,
      "divisions": "",
      "circle": "",
      "oprn_cat_tree": "",
      "area": "",
      "branch": "",
      "reporting_office_name": "",
      "reporting_officer_sap_code": "",
    }
  }

  // to get the data based on click of treemap

  gettop_manager_global_Filters(tree_map_filter_data) {

    var temp = {
      "oprn_category": this.filterValue.oprn_category,
      "quarter": this.filterValue.quarter,
      "year": this.filterValue.year,
      "divisions": "",
      "circle": "",
      "oprn_cat_tree": "",
      "area": "",
      "branch": "",
      "reporting_office_name": "",
      "reporting_officer_sap_code": "",
      "limit": ""
    }

    temp = Object.assign(temp, tree_map_filter_data)

    return temp
  }

  get_achivement_a_b_c_d_percent_data(){
    
    this.achievementData_subscribe = this.api.achievementData(this.filterValue).subscribe(res => {
      if (res["data"]["achievement_data"][0]["total_achievement"] !== null) {
        this.total_achievement = res["data"]["achievement_data"][0]["total_achievement"].toFixed(2);
      }
    });

    this.getFilterData_subscribe = this.api.d_month_avg(this.filterValue).subscribe(res => {
      this.d_month_performer = res['data']['month_wise_low_performer'];
    });
    this.api.a_month_avg(this.filterValue).subscribe(res => {
      this.a_month_performer = res['data']['month_wise_high_performer'];
    });
    this.api.b_month_avg(this.filterValue).subscribe(res => {
      this.b_month_performer = res['data']['month_wise_b_performer'];
    });
    this.api.c_month_avg(this.filterValue).subscribe(res => {
      this.c_month_performer = res['data']['month_wise_c_performer'];
    });


    this.achievementsChart_subscribe = this.api.achievementsChart(this.filterValue).subscribe(res => {
      
      this.twAreaChartData = res["data"];
    });


  }

  bin_histogram_data(res,key){
    var width = 0;
    let self = this;
    let data: any = res["data"],

    minValue: any = d3.min(data, function (d: any) {
      return d[key];
    }),
    maxValue: any = d3.max(data, function (d: any) {
      return d[key];
    });

  let binScale: any = d3.scaleLinear()
    .domain([minValue, maxValue])
    .rangeRound([0, width]);

  let histogram = d3.histogram()
    .value(function (d: any) { return d[key]; })
    .domain(binScale.domain())
  return histogram(data);


  }

  getYearBuData() {

    this.tree_map_filter = {
      "oprn_cat_tree": "",
      "circle": "",
      "divisions": "",
      "area": "",
      "branch": "",
      "p_category": ""
    }

  
    this.api.getYearBuData().subscribe(res => {
      
      this.itemList = res["data"]["bu_data"];
      this.selectedItems = [...res["data"]["bu_data"]];
      this.yearData = res["data"]["year_data"];
      this.filterValue = {
        oprn_category: [],
        quarter: [],
        year: res["data"]["year_data"][0]["itemName"]
      }
      this.filterValue.oprn_category = res["data"]["intial_bu_data"];
      this.filterValue.quarter = this.qualrter_list;

      this.filterValue = Object.assign(this.filterValue, this.tree_map_filter)

      this.globalFilter = this.getGlobalFilters();
      this.fetchChartData(this.globalFilter)
      this.top_manager_table_filter = this.gettop_manager_global_Filters(this.tree_map_filter)

      //achievement data
this.get_achivement_a_b_c_d_percent_data()

      this.performanceData()

      this.fetch_current_total_exp_month_range_data()
      this.fetch_current_total_exp_range_data()
    });
  }

  treemap_filter() {
    this.filterValue = Object.assign(this.filterValue, this.tree_map_filter)
    this.top_manager_table_filter = this.gettop_manager_global_Filters(this.tree_map_filter)

    //achievement data
    this.get_achivement_a_b_c_d_percent_data()

  
    this.performanceData()

    this.fetch_current_total_exp_month_range_data()
    this.fetch_current_total_exp_range_data()
  };

  //bu selection

  onItemSelect(item: any) {
    this.filterValue.oprn_category.push(item.itemName);
  }

  onItemDeSelect(item: any) {
    for (var i = 0; i < this.filterValue.oprn_category.length; i++) {
      if (this.filterValue.oprn_category[i] === item["itemName"]) {
        this.filterValue.oprn_category.splice(i, 1);
        break;
      }
    }
  }

  onSelectAll(items: any) {
    for (let i of items) {
      this.filterValue.oprn_category.push(i["itemName"]);
    }
  }

  onDeSelectAll(items: any) {
    this.filterValue.oprn_category.splice(items);
  }

  //quarter selection

  onQuarterSelect(item: any) {
    this.filterValue.quarter.push(item.itemName);
  }

  OnQuarterDeSelect(item: any) {
    for (var i = 0; i < this.filterValue.quarter.length; i++) {
      if (this.filterValue.quarter[i] === item["itemName"]) {
        this.filterValue.quarter.splice(i, 1);
        break;
      }
    }
  }


  onQuarterSelectAll(items: any) {
    for (let i of items) {
      this.filterValue.quarter.push(i["itemName"]);
    }
  }
  onQuarterDeSelectAll(items: any) {
    this.filterValue.quarter.splice(items);
  }

  yvalue(event) {
    this.filterValue.year = event.target.value;
  }

  filterSubmit() {
    this.tree_map_filter = {
      "oprn_cat_tree": "",
      "circle": "",
      "divisions": "",
      "area": "",
      "branch": "",
      "reporting_office_name": "",
      "reporting_officer_sap_code": "",
      "p_category": ""
    }
    this.current_role_month_exp = []
    this.current_role_exp = []
    this.temp_object_exp_month = {}
    this.temp_object_exp_year = {}
    this.temp_object_age = {}
    this.temp_object = {}
    this.filterValue = Object.assign(this.filterValue, this.tree_map_filter)
    this.globalFilter = this.getGlobalFilters()
    this.fetchChartData(this.globalFilter)
    this.top_manager_table_filter = this.gettop_manager_global_Filters(this.tree_map_filter)


  //achivement_data
  this.get_achivement_a_b_c_d_percent_data()

    this.api.achievementsChart(this.filterValue).subscribe(res => {
      this.twAreaChartData = res["data"];
    });

    this.performanceData()
    this.fetch_current_total_exp_month_range_data()
    this.fetch_current_total_exp_range_data()
  }
  common_function_absolute_data(data, temp_key, h_name) {
    let temp_list = []
    _.each(data, function (d) {
      let temp = Object.assign({}, d);
      temp.key = temp[temp_key];
      temp.total = temp.total_count;
      temp = _.omit(temp, [temp_key, 'total_count']);
      temp.x = h_name;
      temp_list.push(temp);
    })
    return temp_list
  }
  common_function_percentage_data(data, temp_key, h_name) {
    let temp_list = []
    _.each(data, function (d) {
      let temp = Object.assign({}, d);
      temp.key = temp[temp_key];
      temp.total = temp.total_count;
      temp = _.omit(temp, [temp_key, 'total_count']);
      if (temp.total !== 0) {
        temp.a_count = temp.a_count * 100 / temp.total;
        temp.b_count = temp.b_count * 100 / temp.total;
        temp.c_count = temp.c_count * 100 / temp.total;
        temp.d_count = temp.d_count * 100 / temp.total;
      }
      temp.x = h_name;
      temp_list.push(temp);
    })
    return temp_list
  }
  // stack bar chart data manipulation //

  temporry_function_to_order(res) {
    let self = this

    Object.keys(res.data).forEach(function (element) {
      self.temp_asc_dict[element] = []
      res.data[element].forEach(function (new_element) {
        let temp_dict = _.omit(new_element, "a_count", "b_count", "c_count", "d_count")
        temp_dict["a_count"] = new_element["a_count"]
        temp_dict["b_count"] = new_element["b_count"]
        temp_dict["c_count"] = new_element["c_count"]
        temp_dict["d_count"] = new_element["d_count"]
        self.temp_asc_dict[element].push(temp_dict)
      })
    })
    $.extend(true, this.csv_data, this.temp_asc_dict);
  }

  //......................... stack bar chart service.............................. //

  performanceData() {
    let self = this
    var rewdList = [];
    var rewdPercentList = [];


    this.api.tier_data(this.filterValue).subscribe(res => {
      self.temporry_function_to_order(res)
      this.tier_data = this.common_function_absolute_data(this.temp_asc_dict.tier_data, 'tier', 'Tier')
      this.tier_percent_data = this.common_function_percentage_data(this.temp_asc_dict.tier_data, 'tier', 'Tier')
      this.csv_percent_data["tier_data"] = [...this.tier_percent_data]
    })
    this.fetch_age_range_data()
    this.fetch_leave_range_data()
    this.fetch_compensation_range_data()
    // Performance by Language count

    this.lang_subscribe = this.api.language_count_graph_bar_graph_api(this.filterValue).subscribe(res => {
      self.temporry_function_to_order(res)
      this.langData = this.common_function_absolute_data(this.temp_asc_dict.performer_by_language_count, 'languages_known_count', 'No. of Languages Known')
      this.langDataPercent = this.common_function_percentage_data(this.temp_asc_dict.performer_by_language_count, 'languages_known_count', 'No. of Languages Known')
      this.csv_percent_data["performer_by_language_count"] = [...this.langDataPercent]
    })
    // Performance by Grade

    this.grade_subscribe = this.api.grade_bar_graph_api(this.filterValue).subscribe(res => {
      self.temporry_function_to_order(res)
      this.gradeData = this.common_function_absolute_data(this.temp_asc_dict.grade_based_performer, 'grade_name', 'Grade')
      this.gradeDataPercent = this.common_function_percentage_data(this.temp_asc_dict.grade_based_performer, 'grade_name', 'Grade')
      this.csv_percent_data["grade_based_performer"] = [...this.gradeDataPercent]
    })

    // Performance by Training Data

    this.training_subscribe = this.api.training_data_bar_graph_api(this.filterValue).subscribe(res => {
      self.temporry_function_to_order(res)
      this.trainData = this.common_function_absolute_data(this.temp_asc_dict.performer_by_training, 'training_data', 'Training')
      this.trainDataPercent = this.common_function_percentage_data(this.temp_asc_dict.performer_by_training, 'training_data', 'Training')
      this.csv_percent_data["performer_by_training"] = [...this.trainDataPercent]
    })
    // Performance by Operation Category

    this.opr_subscribe = this.api.operation_category_bar_graph_api(this.filterValue).subscribe(res => {
      self.temporry_function_to_order(res)
      this.OprData = this.common_function_absolute_data(this.temp_asc_dict.oprn_category_based_performer, 'oprn_category', 'Operational category')
      this.OprDataPercent = this.common_function_percentage_data(this.temp_asc_dict.oprn_category_based_performer, 'oprn_category', 'Operational category')
      this.csv_percent_data["oprn_category_based_performer"] = [...this.OprDataPercent]
    })


    // Performance by pip

    this.pip_subscribe = this.api.pip_data_bar_graph_api(this.filterValue).subscribe(res => {
      self.temporry_function_to_order(res)
      this.pip_data = this.common_function_absolute_data(this.temp_asc_dict.performer_by_pip, 'pip_data', 'Pip')
      this.pip_percent = this.common_function_percentage_data(this.temp_asc_dict.performer_by_pip, 'pip_data', 'Pip')
      this.csv_percent_data["performer_by_pip"] = [...this.pip_percent]
    })

    // Performance by Disciplinary

    this.dic_subscribe = this.api.dis_data_bar_graph_api(this.filterValue).subscribe(res => {
      self.temporry_function_to_order(res)
      this.dic_data = this.common_function_absolute_data(this.temp_asc_dict.performer_by_dic, 'dic_data', 'Disciplinary')
      this.dic_percent = this.common_function_percentage_data(this.temp_asc_dict.performer_by_dic, 'dic_data', 'Disciplinary')
      this.csv_percent_data["performer_by_dic"] = [...this.dic_percent]
    })



    // Performance by Reward  

    this.star_subscribe = this.api.star_performer_graph_graph_bar_graph_api(this.filterValue).subscribe(res => {
      self.temporry_function_to_order(res)
      _.each(this.temp_asc_dict.performer_by_star_performer, function (d) {
        let temp = Object.assign({}, d);
        temp.key = temp.star_performer;
        temp.total = temp.total_count;
        temp.x = "Rewards";
        temp = _.omit(temp, ['star_performer', 'total_count']);
        rewdList.push(temp);
      });

      _.each(this.temp_asc_dict.performer_by_star_performer, function (d) {
        let temp = Object.assign({}, d);
        temp.key = temp.star_performer;
        temp.total = temp.total_count;
        temp.x = "Rewards";
        temp = _.omit(temp, ['star_performer', 'total_count']);
        if (temp.total !== 0) {
          temp.a_count = temp.a_count * 100 / temp.total;
          temp.b_count = temp.b_count * 100 / temp.total;
          temp.c_count = temp.c_count * 100 / temp.total;
          temp.d_count = temp.d_count * 100 / temp.total;
        }
        rewdPercentList.push(temp);
      });

      this.gem_subscribe = this.api.gem_performer_bar_graph_api(this.filterValue).subscribe(res => {
        self.temporry_function_to_order(res)
        _.each(this.temp_asc_dict.performer_by_gem_performer, function (d) {
          let temp = Object.assign({}, d);
          temp.key = temp.gem_performer;
          temp.total = temp.total_count;
          temp.x = "Rewards";
          temp = _.omit(temp, ['gem_performer', 'total_count']);
          rewdList.push(temp);
        });
        this.rewdData = rewdList

        _.each(this.temp_asc_dict.performer_by_gem_performer, function (d) {
          let temp = Object.assign({}, d);
          temp.key = temp.gem_performer;
          temp.total = temp.total_count;
          temp.x = "Rewards";
          temp = _.omit(temp, ['gem_performer', 'total_count']);
          if (temp.total !== 0) {
            temp.a_count = temp.a_count * 100 / temp.total;
            temp.b_count = temp.b_count * 100 / temp.total;
            temp.c_count = temp.c_count * 100 / temp.total;
            temp.d_count = temp.d_count * 100 / temp.total;
          }
          rewdPercentList.push(temp);
        });
      })

      this.rewdDataPercent = rewdPercentList;
      this.csv_percent_data["performer_by_gem_performer"] = [...rewdPercentList]
    })


  }

  // Binning function for range data

  common_function(bin_data, object) {
    bin_data.forEach(function (xox1) {
      var element = _.omit(xox1, ['x0', 'x1']);
      let total_count = 0
      object[xox1["x0"] + "-" + xox1["x1"]] = {}
      object[xox1["x0"] + "-" + xox1["x1"]]["a_count"] = 0
      object[xox1["x0"] + "-" + xox1["x1"]]["b_count"] = 0
      object[xox1["x0"] + "-" + xox1["x1"]]["c_count"] = 0
      object[xox1["x0"] + "-" + xox1["x1"]]["d_count"] = 0

      object[xox1["x0"] + "-" + xox1["x1"]]["total_count"] = 0

      Object.values(element).forEach(function (element2) {
        object[xox1["x0"] + "-" + xox1["x1"]]["d_count"] += element2["d_count"]
        object[xox1["x0"] + "-" + xox1["x1"]]["c_count"] += element2["c_count"]
        object[xox1["x0"] + "-" + xox1["x1"]]["b_count"] += element2["b_count"]
        object[xox1["x0"] + "-" + xox1["x1"]]["a_count"] += element2["a_count"]


        object[xox1["x0"] + "-" + xox1["x1"]]["total_count"] += element2["total_count"]
      })
    })
    return object
  }

  // Performance by age range

  fetch_age_range_data() {
    var width = 0;
    let self = this;
    let ageRangeList = [];
    let agePercentList = [];

    this.age_subscribe = this.api.age_range_api(this.filterValue).subscribe(res => {
      if (res["data"].length != 0) {
        

        //   minValue: any = d3.min(data, function (d: any) {
        //     return d.emp_age;
        //   }),
        //   maxValue: any = d3.max(data, function (d: any) {
        //     return d.emp_age;
        //   });

        // let binScale: any = d3.scaleLinear()
        //   .domain([minValue, maxValue])
        //   .rangeRound([0, width]);

        // let histogram = d3.histogram()
        //   .value(function (d: any) { return d.emp_age; })
        //   .domain(binScale.domain())

        var bins = self.bin_histogram_data(res,"emp_age")
        this.age_by_range.length = 0


        self.temp_object_age = {}

        self.temp_object_age = this.common_function(bins, self.temp_object_age)

        let temp_keys = Object.keys(self.temp_object_age)
        temp_keys.forEach(function (element) {

          self.temp_object_age[element]["age_range"] = element

          self.age_by_range.push(self.temp_object_age[element])
        });


        this.age_data = [...this.age_by_range]
        this.csv_data["performer_by_age"] = [...self.age_data]

        this.age_data_performance = this.common_function_absolute_data(this.age_data, 'age_range', 'Age Group')
        this.age_data_percent = this.common_function_percentage_data(this.age_data, 'age_range', 'Age Group')
        this.csv_percent_data["performer_by_age"] = [...this.age_data_percent]
      }
      else {
        this.age_data_performance = []
        this.age_data_percent = []

      }
    })
  }

  // Performance by leave range

  fetch_leave_range_data() {
    var width = 0;
    let self = this;
    let leaveRangeList = [];
    let leavePercentList = [];

    this.leave_subscribe = this.api.leave_range_api(this.filterValue).subscribe(res => {
      if (res["data"].length != 0) {
        
        //   minValue: any = d3.min(data, function (d: any) {
        //     return d.leave_count;
        //   }),
        //   maxValue: any = d3.max(data, function (d: any) {
        //     return d.leave_count;
        //   });

        // let binScale: any = d3.scaleLinear()
        //   .domain([minValue, maxValue])
        //   .rangeRound([0, width]);

        // var histogram = d3.histogram()
        //   .value(function (d: any) { return d.leave_count; })
        //   .domain(binScale.domain())
        var bins  = self.bin_histogram_data(res,"leave_count")
        this.leave_by_range.length = 0
        self.temp_object = {}
        self.temp_object = this.common_function(bins, self.temp_object)
        let temp_keys = Object.keys(self.temp_object)
        temp_keys.forEach(function (element) {
          self.temp_object[element]["leave_range"] = element
          self.leave_by_range.push(self.temp_object[element])
        })

        this.csv_data["performer_by_leave_count"] = [...this.leave_by_range]
        this.leave_data = [...this.leave_by_range]
        this.leave_data_performance = this.common_function_absolute_data(this.leave_data, 'leave_range', 'Leave Range(No.of days)')
        this.leave_data_percent = this.common_function_percentage_data(this.leave_data, 'leave_range', 'Leave Range(No.of days)')
        this.csv_percent_data["performer_by_leave_count"] = [...this.leave_data_percent]
      } else {
        this.leave_data_performance = []
        this.leave_data_percent = []

      }
    })
  }


  fetch_compensation_range_data() {
    var width = 0;
    let self = this;

    this.api.compemsation_data(this.filterValue).subscribe(res => {
      if (res["data"].length != 0) {
        // let data: any = res["data"]
        //   minValue: any = d3.min(data, function (d: any) {

        //     return d.percentile;
        //   }),
        //   maxValue: any = d3.max(data, function (d: any) {

        //     return d.percentile;
        //   });

        // let binScale: any = d3.scaleLinear()
        //   .domain([minValue, maxValue])
        //   .rangeRound([0, width]);

        // var histogram = d3.histogram()
        //   .value(function (d: any) { return d.percentile; })
        //   .domain(binScale.domain())
        var bins  = self.bin_histogram_data(res,"percentile")
        self.compensation_by_range.length = 0
        self.temp_object_comensation = {}
        self.temp_object_comensation = this.common_function(bins, self.temp_object_comensation)

        let temp_keys = Object.keys(self.temp_object_comensation)
        temp_keys.forEach(function (element) {

          self.temp_object_comensation[element]["percentile"] = element
          self.compensation_by_range.push(self.temp_object_comensation[element])
        })
        this.csv_data["performer_by_Compensation"] = [...this.compensation_by_range]
        this.compensation_data = [...this.compensation_by_range]

        this.compensation_data_performence = this.common_function_absolute_data(this.compensation_data, 'percentile', 'Compenstion')
        this.compensation_percent = this.common_function_percentage_data(this.compensation_data, 'percentile', 'Compensation')
        this.csv_percent_data["performer_by_Compensation"] = [...this.compensation_percent]
      } else {
        this.compensation_data_performence = []
        this.compensation_percent = []
      }
    })
  }


  // data manipulation for experience and role based performance

  fetch_current_total_exp_month_range_data() {
    var width = 0;
    let self = this;

    this.month_range_subscribe = this.api.experience_in_current_role_range_api(this.filterValue).subscribe(res => {
      if (res["data"].length != 0) {
        self.current_role_month_exp.length = 0
        // let data: any = res["data"]
        //   minValue: any = d3.min(data, function (d: any) {
        //     return d.experience;
        //   }),
        //   maxValue: any = d3.max(data, function (d: any) {
        //     return d.experience;
        //   });

        // let binScale: any = d3.scaleLinear()
        //   .domain([minValue, maxValue])
        //   .rangeRound([0, width]);

        
        // var histogram = d3.histogram()
        //   .value(function (d: any) { return d.experience; })
        //   .domain(binScale.domain())
        var bins = self.bin_histogram_data(res,"experience")
        self.temp_object_exp_month = {};
        self.temp_object_exp_month = this.common_function(bins, self.temp_object_exp_month)

        let temp_keys = Object.keys(self.temp_object_exp_month)
        temp_keys.forEach(function (element) {

          self.temp_object_exp_month[element]["exp_range"] = element
          self.current_role_month_exp.push(self.temp_object_exp_month[element])
        })
        this.csv_data["performer_by_experience_in_current_role"] = [...this.current_role_month_exp]
        this.current_month_exp_data = {}
        this.current_month_exp_data = [...this.current_role_month_exp]

        this.exp_month_data = this.common_function_absolute_data(this.current_month_exp_data, 'exp_range', 'Month Range')


        this.exp_month_data_percent = this.common_function_percentage_data(this.current_month_exp_data, 'exp_range', 'Month Range')
        this.csv_percent_data["performer_by_experience_in_current_role"] = [...this.exp_month_data_percent]

      } else {
        this.exp_month_data = []
        this.exp_month_data_percent = []
      }
    })
  }


  fetch_current_total_exp_range_data() {
    var width = 0;
    let self = this;

    this.exp_range_subscribe = this.api.performer_by_experience_in_mf_range_api(this.filterValue).subscribe(res => {
      if (res["data"].length != 0) {
        self.current_role_exp.length = 0

        // let data: any = res["data"]
        //   minValue: any = d3.min(data, function (d: any) {
        //     return d.experience_year;
        //   }),
        //   maxValue: any = d3.max(data, function (d: any) {
        //     return d.experience_year;
        //   });

        // let binScale: any = d3.scaleLinear()
        //   .domain([minValue, maxValue])
        //   .rangeRound([0, width]);
        
        // var histogram = d3.histogram()
        //   .value(function (d: any) { return d.experience_year; })
        //   .domain(binScale.domain())
        var bins = self.bin_histogram_data(res,"experience_year")

        self.temp_object_exp_year = {}
        self.temp_object_exp_year = this.common_function(bins, self.temp_object_exp_year)

        let temp_keys = Object.keys(self.temp_object_exp_year)
        temp_keys.forEach(function (element) {

          self.temp_object_exp_year[element]["exp_range"] = element
          self.current_role_exp.push(self.temp_object_exp_year[element])
        })

        this.current_exp_data = [...this.current_role_exp]
        this.csv_data["performer_by_experience_in_mf"] = [...this.current_role_exp]
        this.exp_data_performance = this.common_function_absolute_data(this.current_exp_data, 'exp_range', 'Year Range')
        this.exp_data_performance_percent = this.common_function_percentage_data(this.current_exp_data, 'exp_range', 'Year Range')
        this.csv_percent_data["performer_by_experience_in_mf"] = [...this.exp_data_performance_percent]
      } else {
        this.exp_data_performance = []
        this.exp_data_performance_percent = []
      }
    })
  }
  download($event, value_name, range_value, per_value, file_name) {
    var data = []
    if (per_value == "true") {
      data = this.csv_percent_data
    } else {
      data = this.csv_data
    }

    this.csv_object.download_csv($event, value_name, range_value, per_value, file_name, data)
  }

  dom_to_img(event, chart_name) {
    Utils.dom_to_img(event.target, chart_name);
  }

  temp_function(data) {
    this.tree_map_filter = data
    this.treemap_filter()
  }

  clickFilter(event) {

    let self = this
    $(".serie rect", function () {
      
      if ($(".serie rect").hasClass('active')) {
        
        var grade_obj = { "a_count": "A", "b_count": "B", "c_count": "C", "d_count": "D" }
        self.barFilter["p_category"] = grade_obj[event];
        
        var temp_obj = {}
        temp_obj = Object.assign(temp_obj, self.filterValue)
        temp_obj = Object.assign(temp_obj, self.barFilter)
        self.top_manager_table_filter = temp_obj
      }
      else {
       
        self.barFilter["p_category"] = ""
        var temp_obj = {}
        temp_obj = Object.assign(temp_obj, self.filterValue)
        temp_obj = Object.assign(temp_obj, self.barFilter)
        self.top_manager_table_filter = temp_obj
      }
    })
  }

  fetchChartData(data): void {
    var self = this
    var temp_data: any = {}

    this.api.tree_map(data).subscribe((res: any, ) => {

      temp_data.filters = this.globalFilter
      temp_data.data = res.data
      self.tree_map_flatData = temp_data
    });
  }

  insightRangeResponse(event, requestdata) {
    $(event).closest(".col-left").find(".insight-res").show();
    $(".insight-res .fa-times").click(function () {
      $(this).closest(".insight-res").hide()
      $(".insight-data li").remove()
    })

    $(event).closest(".col").find(".insight-res").show();
    $(".insight-res .fa-times").click(function () {
      $(this).closest(".insight-res").hide()
      $(".insight-data li").remove()
    })

    if (requestdata != null) {
      this.api.insightgraphstackbarRange(requestdata).subscribe((res: any) => {
        this.insighters_data = res.data
        for (let i of this.insighters_data) {
          this.insightres = i;
          $(event).closest(".col-left").find(".insight-data")
            .append("<li>" + this.insightres + "</li>");
          $(event).closest(".col").find(".insight-data")
            .append("<li>" + this.insightres + "</li>");
        }
      })

    }

  }
  // sending respone for graph insight
  insightResponse(event, requestdata) {

    $(event).closest(".col-left").find(".insight-res").show();
    $(".insight-res .fa-times").click(function () {
      $(this).closest(".insight-res").hide()
      $(".insight-data li").remove()
    })

    $(event).closest(".col").find(".insight-res").show();
    $(".insight-res .fa-times").click(function () {
      $(this).closest(".insight-res").hide()
      $(".insight-data li").remove()
    })

    if (requestdata != null) {
      this.api.insightgraphstackbar(requestdata).subscribe((res: any) => {
        this.insighters_data = res.data
        for (let i of this.insighters_data) {
          this.insightres = i;
          $(event).closest(".col-left").find(".insight-data")
            .append("<li>" + this.insightres + "</li>");
          $(event).closest(".col").find(".insight-data")
            .append("<li>" + this.insightres + "</li>");
        }
      })

    }

  }
}