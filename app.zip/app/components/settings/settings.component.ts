import { Component, OnInit } from "@angular/core";
import { ProjectServiceService } from "../../common/services/project-service.service";

@Component({
  selector: "app-settings",
  templateUrl: "./settings.component.html",
  styleUrls: ["./settings.component.css"]
})
export class SettingsComponent implements OnInit {
  getFirstName: any;
  getLastName: any;
  getRole: any;
  getEmail: any;
  getId: any;
  UpdateStatus: any;

  model: any;
  constructor(private service: ProjectServiceService) { }

  ngOnInit() {
    this.getFirstName = localStorage.getItem("firstName");
    this.getLastName = localStorage.getItem("lastName");
    this.getRole = localStorage.getItem("roleName");
    this.getEmail = localStorage.getItem("email");
    this.getId = localStorage.getItem("userid");
    this.model = {
      first_name: this.getFirstName,
      last_name: this.getLastName,
      role: this.getRole,
      email: this.getEmail,
      user_id: this.getId
    };

  }

  editUser(data) {
    let editUser = {};
    let userEditData = {};
    userEditData["user_id"] = this.getId;
    userEditData["first_name"] = data.first_name;
    userEditData["last_name"] = data.last_name;
    editUser["role"] = data.role;
    editUser["user"] = userEditData;
    localStorage.removeItem("firstName");
    localStorage.removeItem("lastName");

    localStorage.setItem("firstName", data.first_name);
    localStorage.setItem("lastName", data.last_name);

    this.service.userEdit(editUser).subscribe(res => {
      if (res["message"] === "success") {
        this.UpdateStatus = "Profile updated Successfully."
        $('.msg_display .text-success').text(this.UpdateStatus).show().fadeOut(4000);
      }
    });
  }
}
