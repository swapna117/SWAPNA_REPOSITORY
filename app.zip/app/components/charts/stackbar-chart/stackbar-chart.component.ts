import { Component, OnInit, Input, ViewChild, ElementRef, OnChanges, Output } from '@angular/core';
import * as d3 from 'd3';
import * as d3Tip from 'd3-tip';
import * as _ from 'lodash';
import { Utils, CapitalizePipe } from 'src/app/common/shared/utility';
import { EventEmitter } from '@angular/core';
import * as $ from 'jquery';
@Component({
  selector: 'app-stackbar-chart',
  templateUrl: './stackbar-chart.component.html',
  styleUrls: ['./stackbar-chart.component.css'],
})
export class StackbarChartComponent implements OnInit {
  private host;
  private svg;
  private tipObject;
  private margin;
  private width;
  private height;
  private xScale;
  private yScale;
  private colorScale;
  private currElement: HTMLElement;
  private htmlElement: HTMLElement;
  private elmWidth;
  temp = true
  private capitalize = CapitalizePipe.prototype.transform;

  @Input() chart_height:any = 340
  @Input() data : any;
  @Output() public barClick : EventEmitter<any> = new EventEmitter();
  @ViewChild('chartContainer') element: ElementRef;

  constructor(private elRef: ElementRef) {
    this.currElement = this.elRef.nativeElement;
  }

  ngOnInit() {
    let self = this;

    self.tipObject = (<any>d3Tip)()
    .attr('class', 'd3-tip d3-tip-stacked-bar')
    .offset([-10, 0])
    .html(function (d) {
      return '<p><span class="title">' + d.data.x + ' : ' + '</span>' + d.data.key + '</p>'
          + '<p><span class="title">' + self.capitalize(d.serieKey) + ': </span>' + (d[1] - d[0]) + '</p>';
    });
  }

  // onResize(event) {
  //   location.reload();
  // }
  
  ngOnChanges(changes): void {
    let self = this;

    if (changes.data && changes.data.currentValue !== undefined) {
      Utils.setContainerState(self.currElement,'loading');
      setTimeout(function () {
        self.stackedBar();
      }, 500);
    }

    this.elmWidth = this.element.nativeElement.offsetWidth;
    this.htmlElement = this.element.nativeElement;
    this.host = d3.select(this.htmlElement);
    this.setup();
  }

  private setup(): void {
    this.margin = { top: 60, right: 30, bottom: 45, left: 60 };
    this.width = this.elmWidth - this.margin.left - this.margin.right;
    this.height =  this.chart_height - this.margin.top - this.margin.bottom;
    this.xScale = d3.scaleBand().rangeRound([this.width, 0])
        .padding(0.3)
        .align(0.3);
    this.yScale = d3.scaleLinear().rangeRound([this.height, 0]);
    this.colorScale = d3.scaleOrdinal()
        .range(["#ff2828","	#FF8C00" , "#FFD700", "#4ed54e"])
        .domain(["d_count", "c_count", "b_count","a_count"]);
  }


  // ** STACKED BAR CHART **//

  stackedBar(){
    let self = this;
    self.host.html('');

    if (_.isEmpty(self.data)) {
      Utils.setContainerState(self.currElement, "nodata");
      return;
    };
    Utils.setContainerState(self.currElement, "done-loading");
    
    let columns: any = _.chain(self.data[0]).omit(['key', 'total','x']).keys().value();
        
    self.svg = self.host.append('svg')
      .attr('width', self.width + self.margin.left + self.margin.right)
      .attr('height', self.height + self.margin.top + self.margin.bottom);


    let mainG = self.svg.append("g")
      .attr("transform",
        "translate(" + self.margin.left + "," + self.margin.top + ")");

    let stack = d3.stack();
    let x_lable = this.data;

    self.xScale.domain(self.data.map(function (d) { return d.key; }).reverse());
    self.yScale.domain([0, d3.max(self.data, function (d: any): number { return d.total; })]).nice();

    let stackData = stack.keys(columns)(self.data);
    _.each(stackData, function(serie) {
      serie.forEach(function(d) {
        d.serieKey = serie.key;
        d.data.serieKey = serie.key;

      });
    });

    let serie = mainG.selectAll(".serie")
      // .data(stack.keys(columns)(self.data))
      .data(stackData)
      .enter().append("g")
      .attr("class", function(d) {
        return "serie " + d.key;
      })
      .attr("fill", function (d) { return self.colorScale(d.key); })
      .attr("data-class", function(d) {
        return d.key;
      });

    serie.selectAll("rect")
      .data(function (d) { return d; })
      .enter()
      .append("rect")
      .attr("x", function (d: any) { return self.xScale(d.data.key); })
      .attr("y", function (d) { return self.yScale(d[1]); })
      .attr("height", function (d) { return self.yScale(d[0]) - self.yScale(d[1]); })
      .attr("width", self.xScale.bandwidth())
      .on('mouseover', self.tipObject.show)
      .on('mouseout', self.tipObject.hide)
      .on('click',(d:any) =>{
        this.barClick.emit(d.serieKey)
      });

    self.svg.call(self.tipObject);

    mainG.append("g")
      .attr("class", "axis axis--x")
      .attr("transform", "translate(0," + self.height + ")")
      .call(d3.axisBottom(self.xScale))
      .selectAll("text")
      .style("font-size","11px")
      .attr("y", 15)
      .attr("x", -10)
      .attr("dy", ".35em")
      .attr("transform", "rotate(-15)")
      .style("text-anchor", "middle");

    // text label for the y axis
    mainG.append("text")
    .attr("transform", "rotate(-90)")
    .attr("y", 0 - this.margin.left)
    .attr("x",0 - (this.height / 2))
    .attr("dy", "1.5em")
    .style("font-size","13px")
    .style("font-family","openSans_regular")
    .style("text-anchor", "middle")
    .text("Performance"); 

    mainG.append("g")
      .attr("class", "axis axis--y")
      .call(d3.axisLeft(self.yScale).ticks(10, "s"))
      .style("font-size","11px")


    // text label for the x axis
    mainG.append("text")             
      .attr("transform",
            "translate(" + (this.width/2) + ", " + (this.height + this.margin.top + 20) + ")")
      .style("text-anchor", "middle")
      .style("font-family","openSans_regular")
      .attr("dy", "-3em")
      .style("font-size","13px")
      .text(x_lable[0].x);

  }
}