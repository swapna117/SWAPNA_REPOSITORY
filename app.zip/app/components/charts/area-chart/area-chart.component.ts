import {
  Component,
  OnInit,
  Input,
  OnChanges,
  ViewChild,
  ElementRef
} from "@angular/core";
import * as d3 from "d3";
import * as d3Tip from 'd3-tip';
import { Utils } from "src/app/common/shared/utility";
import * as _ from "lodash";


@Component({
  selector: "app-area-chart",
  templateUrl: "./area-chart.component.html",
  styleUrls: ["./area-chart.component.css"]
})
export class AreaChartComponent implements OnInit, OnChanges {
  @Input() data: any;
  @ViewChild("chartContainer") element: ElementRef;
 
  svg:any;
  margin:any;
  graphWidth:any;
  graphHeight:any;
  x:any;
  y:any;
  tipObject:any;
  area:any;
  valueline:any;
  data_count:number;
  private currElement:HTMLElement;
  private elmWidth;

  private formatDateToMonth = d3.timeFormat("%B");

  constructor(private elRef: ElementRef) {
    this.currElement = this.elRef.nativeElement;
  }
  
  
  ngOnInit() {
    let self = this
    this.drawChart();
    this.elmWidth = this.element.nativeElement.offsetWidth;    
    self.tipObject = (<any>d3Tip)()
      .attr('class', 'd3-tip d3-tip-treemap')
      .offset([-10, 0])
      .html(function (d) {
        return '<p><span class="title"> ' + "Month:" + '</span>'+ " " + self.formatDateToMonth(d.month) + '</p>'
        + '<p><span class="title">' + "RBMI avg. Percent" + ': </span>' + d.avg + '%' + '</p>'
        + '<p><span class="title">' + "operation category: " + ': </span>' + d.oprn_category + '</p>';
      }
    );
  }

  ngOnChanges(changes): void {    
    if (changes.data.currentValue !== undefined) {
      this.drawChart();
    }
  }

  drawChart() {
    var self = this
    //svg for the chart    
    $(".canvas").html("");
    if (!this.data) return;

    if (_.isEmpty(self.data)) {
      Utils.setContainerState(self.currElement, "nodata");
      return;
    };
    Utils.setContainerState(self.currElement, "done-loading");

    //create margins and dimensions
    this.margin = { top: 20, right: 10, bottom: 20, left: 25};
    this.graphWidth = this.elmWidth - this.margin.left - this.margin.right ;
    this.graphHeight = 125- this.margin.top - this.margin.bottom;

    this.svg = d3
      .select(".canvas")
      .append("svg")
      .attr("width", this.elmWidth)
      .attr("height", 145);

    let graph = this.svg
      .append("g")
      .attr("transform", `translate(${this.margin.left},${this.margin.top  + 20})`);

    var parseTime = d3.timeParse("%B");
    
    var self = this;
    // set the ranges
    this.x = d3.scaleTime().range([0, this.graphWidth]);
    this.y = d3.scaleLinear().range([this.graphHeight, 0]);

    // format the data
    self.data_count = 0
    this.data.forEach(function(d) {
      self.data_count = self.data_count+1      
      d.month = parseTime(d.month);
      d.avg = d.average;
    });
    
    // define the area
    this.area = d3
      .area()
      .x(function(d:any) {
        return self.x(d.month);
      })
      .y0(this.graphHeight)
      .y1(function(d:any) {
        return self.y(d.avg);
      })
      
    // define the line
    this.valueline = d3
      .line()
      .x(function(d:any) {
        return self.x(d.month);
      })
      .y(function(d:any) {
        return self.y(d.avg);
      });


    // scale the range of the data
    this.x.domain(
      d3.extent(this.data, function(d:any) {
        return d.month;
      })
    );
    this.y.domain([
      0,
      d3.max(this.data, function(d:any) {
        return d.avg;
      })
    ]);

    // add the area
    graph
      .append("path")
      .data([this.data])
      .attr("class", "area")
      .style("fill", "lightsteelblue")
      .attr("d", this.area);

    // add the valueline path.
    graph
      .append("path")
      .data([this.data])
      .attr("class", "line")
      .style("fill", "none")
      .style("stroke", "steelblue")
      .style("stroke - width", "2px")
      .attr("d", this.valueline);
    
    graph.selectAll("circle")
      .data(this.data)
      .enter()
      .append("circle")
      .attr("class", "circle")
      .attr("cx", function(d:any) {
        return self.x(d.month);
      })
      .attr("cy", function(d:any) {
        return self.y(d.avg);
      })
      .attr("r", "3")
      .style("fill", "steelblue")
      .style("opacity", ".7")
      .on('mouseover', self.tipObject.show)
      .on('mouseout', self.tipObject.hide);

    graph.call(self.tipObject);
    // add the X Axis
    
    graph
      .append("g")
      .attr("transform", "translate(0," + this.graphHeight + ")")
      .call(d3.axisBottom(this.x).scale(this.x)
          .ticks(d3.timeMonth)
          .tickFormat(d3.timeFormat("%b")));

    // add the Y Axis
    graph.append("g").call(d3.axisLeft(this.y).ticks(5 , "s"))
  }
}
