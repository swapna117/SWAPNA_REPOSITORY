import { Component, OnInit, Input, ElementRef, ViewChild } from '@angular/core';
import * as d3 from 'd3';
import { PredictiveTabServiceService } from 'src/app/common/services/predictive-services/predictive-tab-service.service';
import { Utils } from 'src/app/common/shared/utility';
import * as _ from 'lodash';
@Component({
  selector: 'app-parameters-bar-chart',
  templateUrl: './parameters-bar-chart.component.html',
  styleUrls: ['./parameters-bar-chart.component.css']
})
export class ParametersBarChartComponent implements OnInit {
  line_chart_data = []
  low_performer_percentage: Number;
  private elmWidth;
  y: any;
  private currElement: HTMLElement;
  private htmlElement: HTMLElement;
  @ViewChild('chartContainer') element: ElementRef;
  @Input() data: any;
  constructor(private api: PredictiveTabServiceService, private elRef: ElementRef) {
    this.currElement = elRef.nativeElement
  }

  ngOnInit() {
  }

  ngOnChanges(changes): void {
    let self = this

    this.elmWidth = this.element.nativeElement.offsetWidth;
    this.htmlElement = this.element.nativeElement;
    this.elmWidth = this.element.nativeElement.offsetWidth;

    if (changes.data.currentValue != undefined) {
      this.fetch_parameters_data(this.data)
    }
  }

  fetch_parameters_data(data) {
    this.line_chart_data = data
    this.build_chart()
  }

  build_chart() {
    let self = this;
    $(".parameters").html("");
    
    if (_.isEmpty(self.data)) {
      Utils.setContainerState(self.currElement, "nodata");
      return;
    };
    Utils.setContainerState(self.currElement, "done-loading");

    //create margins and dimensions
    var margin = { top: 30, right: 10, bottom: 60, left: 10 };
    var width = (this.elmWidth / 2) - margin.left - margin.right
    var height = (440 / 1) - margin.top - margin.bottom;


    var svg = d3.select(".parameters")
      .append("svg")
      .attr("width", this.elmWidth)
      .attr("height", 500)
      .style("margin-top", -55)

    var x = d3.scaleLinear()
      .range([0, width]);

    var y = d3.scaleBand()
      .rangeRound([0, height])
      .padding(0.1);

    var gContainer = svg.append("g")
      .attr("transform", "translate("+ width/2 +", 30)")
      .classed("weekly-container", true);

    var g = gContainer.append("g")
      .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

    this.line_chart_data = this.line_chart_data.sort(d=>d.value).reverse()
    this.line_chart_data.forEach(function (d) {

      d.name = d.name;
      d.value = d.value

    })

    x.domain(d3.extent(this.line_chart_data, function (d) { return d.value; })).nice();
    y.domain(this.line_chart_data.map(function (d) { return d.name; }));

    g.append("g")
      .attr("class", "axis axis-x")
      .attr("transform", "translate(0," + height + ")")
      .call(d3.axisBottom(x)
        .tickFormat(d3.format(".1e")));


    g.selectAll(".bar")
      .data(this.line_chart_data)
      .enter().append("rect")
      .attr("class", function (d) { return "bar bar--" + (d.value < 0 ? "negative" : "positive"); })


      .attr("x", function (d) { return x(Math.min(0, d.value)); })
      .attr("y", function (d) {

        return y(d.name);
      })
      .attr("width", function (d) { return Math.abs(x(d.value) - x(0)); })
      .attr("height", y.bandwidth())
      .attr("fill", function (d) { return d.value < 0 ? "#ccc" : "#007bff"; });


    g.selectAll(".value")
      .data(this.line_chart_data)
      .enter().append("text")

    g.selectAll(".name")
      .data(this.line_chart_data)
      .enter().append("text")
      .attr("class", "name")
      .attr("x", function (d) { return x(0); })
      .attr("y", function (d) { return y(d.name) + (y.bandwidth()/2) })
      .attr("dx", function (d) { return d.value < 0 ? 5 : -5; })
      .attr("dy", 4)
      .attr("text-anchor", function (d) { return d.value < 0 ? "start" : "end"; })
      .text(function (d) { return d.name; })
      .attr("font-size", "13px")


    svg.append("text")
      .attr("transform",
        "translate(" + (width) + ", " + (height + margin.top + margin.bottom + 39) + ")")
      .style("text-anchor", "middle")
      .style("font-family", "openSans_regular")
      .style("margin-top", "4px")
      .attr("dy", "-3em")
      .style("font-size", "13px")
      .text("Importance Coeffients");

    Utils.setContainerState(this.currElement, "done-loading");

  }
}



