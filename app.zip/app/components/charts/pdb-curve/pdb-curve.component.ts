import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { PredictiveTabServiceService } from 'src/app/common/services/predictive-services/predictive-tab-service.service';
import * as d3 from 'd3';
import * as _ from "lodash";
import * as d3Tip from 'd3-tip';
import { CsvDownloaderService } from 'src/app/common/services/csv-downloader.service';
import { Utils } from 'src/app/common/shared/utility';

@Component({
  selector: 'app-pdb-curve',
  templateUrl: './pdb-curve.component.html',
  styleUrls: ['./pdb-curve.component.css']
})

export class PdbCurveComponent implements OnInit {
  pdb_chart_data = [];
  table_filter: any = {}
  drop_down_data = [];
  data = []
  @ViewChild('chartContainer') element: ElementRef;
  private elmWidth;
  y: any;


  private currElement: HTMLElement;
  private htmlElement: HTMLElement;
  constructor(private api: PredictiveTabServiceService, private csv_object: CsvDownloaderService, private elRef: ElementRef) {
    this.currElement = elRef.nativeElement
  }
  tipObject;
  ngOnInit() {

    this.elmWidth = this.element.nativeElement.offsetWidth;
    this.htmlElement = this.element.nativeElement;


    this.elmWidth = this.element.nativeElement.offsetWidth;
    this.get_dropdown_data()

    this.tipObject = (<any>d3Tip)()
      .attr('class', 'd3-tip d3-tip-treemap')
      .offset([-10, 0])
      .html(function (d) {
        return '<p><span style = "color:red;"> ' + '</span>' + d.Average_0.toFixed(2) + '</p>';
      }
      );
  }

  get_dropdown_data() {

    let self = this
    this.api.get_pdb_dropdown().subscribe((res: any, ) => {
      self.drop_down_data = res.data
      this.table_filter.col_name = res.data[0]

      this.get_filter_data()
    })

  }

  get_filter_data() {

    let self = this
    this.api.get_pdb_data({ "feature_col": this.table_filter.col_name }).subscribe((res: any, ) => {
      self.data = res.data

      if (_.isEmpty(res.data)) {
        Utils.setContainerState(self.currElement, "nodata");
        return;
      };
      Utils.setContainerState(self.currElement, "done-loading");
      self.build_chart()
    })
  }
  build_chart() {

    var margin = { top: 20, right: 20, bottom: 30, left: 100 },
      width = this.elmWidth - margin.left - margin.right,
      height = 510 - margin.top - margin.bottom;
    var x = d3.scaleBand().rangeRound([0, width - 150]).padding(.1).paddingOuter(1);;
    var y = d3.scaleLinear().rangeRound([height, 0]);
    var y1 = d3.scaleLinear().range([height, 0]).domain([0, 1]);//marks can have min 0 and max 100

    var yAxisRight = d3.axisRight(y1)
    var color = d3.scaleOrdinal()
    var xAxis = d3.axisBottom(x)
    var yAxis = d3.axisLeft(y)
    $(".pdb_chart").html("");

    var svg = d3.select(".pdb_chart").append("svg")
      .attr("width", width + margin.left + margin.right)
      .attr("height", height + margin.top + margin.bottom + 10)
      .append("g")
      .attr("transform", "translate(" + margin.left + "," + margin.top + ")");
    let self = this
    this.data.forEach(function (d) {
      //filter out name and average

      color.domain(d3.keys(self.data[0]).filter(function (key) { return key !== "Name" && key !== "Average"; }));
      self.data.forEach(function (d) {
        var y0 = 0;
        d.group = color.domain().map(function (name) { return { name: name, y0: y0, y1: y0 += +d[name] }; });
        d.count = d.count
      });
    })

    x.domain(self.data.map(function (d) { return d.Name; }));
    //stores toltal headcount
    y.domain([0, d3.max(self.data, function (d) { return d.count; })]);

    //line function for averageLine
    var averageline_0 = d3.line()
      .x(function (d) { return x(d["Name"]) + x.bandwidth() / 2; })
      .y(function (d) { return y1(d["Average_0"]); });
    var averageline_1 = d3.line()
      .x(function (d) { return x(d["Name"]) + x.bandwidth() / 2; })
      .y(function (d) { return y1(d["Average_1"]); });
    var averageline_2 = d3.line()
      .x(function (d) { return x(d["Name"]) + x.bandwidth() / 2; })
      .y(function (d) { return y1(d["Average_2"]); });
    var averageline_3 = d3.line()
      .x(function (d) { return x(d["Name"]) + x.bandwidth() / 2; })
      .y(function (d) { return y1(d["Average_3"]); });

    //this will make the y axis to teh right
    svg.append("g")
      .attr("class", "y axis")
      .attr("transform", "translate(" + (width - 105) + " ,0)")
      .style("color", "(0, 0, 0)")
      .style("font-family", "openSans_regular")
      .style("stroke", "lightsteelblue")
      .call(yAxisRight);


    svg.append("g")
      .attr("class", "x axis")
      .attr("transform", "translate(0," + height + ")")
      .call(xAxis);

    svg.append("g")
      .attr("class", "y axis")
      .style("stroke", "steelblue")
      .style("fill", "(0, 0, 0)")
      .style("font-size", "10px")
      .style("font-family", "openSans_regular")
      .call(yAxis)

    var state = svg.selectAll(".state")
      .data(self.data)
      .enter().append("g")
      .attr("class", "g")
      .attr("transform", function (d) { return "translate(" + x(d.Name) + ",0)"; });

    //adding the rect for group chart
    state.selectAll("rect")
      .data(function (d) { return d.group; })
      .enter().append("rect")
      .attr("width", x.bandwidth())
      .attr("y", function (d) {
        console.log(d)
        return y(d['y1']);
      })
      .attr("height", function (d) { return y(d['y0']) - y(d['y1']); })
      .style("fill", "steelblue");

    svg.append("path")
      .data([self.data])
      .attr("class", "line")
      .attr("d", averageline_0)
      .attr("stroke", "#4ed54e")
    svg.append("path")
      .data([self.data])
      .attr("class", "line")
      .attr("d", averageline_1)
      .attr("stroke", "#FFD700")

    svg.append("path")
      .data([self.data])
      .attr("class", "line")
      .attr("d", averageline_2)
      .attr("stroke", "#FF8C00")
    svg.append("path")
      .data([self.data])
      .attr("class", "line")
      .attr("d", averageline_3)
      .attr("stroke", "#ff2828")

    var temp_list = [0, 1, 2, 3]
    temp_list.forEach(index => {
      var className = "circle" + index;
      svg.selectAll("circle." + className)
        .data(self.data)
        .enter().append("circle")
        .attr("class", className)
        .attr("cx", function (d: any) {
          return x(d["Name"]) + x.bandwidth() / 2;
        })
        .attr("cy", function (d: any) {
          let key = "Average_" + index
          return y1(d[key]);
        })
        .attr("r", "3.7")
        .style("fill", "lightsteelblue")
        .style("opacity", ".7")
        .on('mouseover', self.tipObject.show)
        .on('mouseout', self.tipObject.hide);

      svg.call(self.tipObject);
    });

    svg.append("text")
      .attr("transform", "rotate(-90)")
      .attr("y", -68)
      .attr("x", 0 - (height / 2))
      .attr("dy", "1.5em")
      .style("font-size", "13px")
      .style("font-family", "openSans_regular")
      .style("text-anchor", "middle")
      .text("Count");

    svg.append("text")
      .attr("transform", "rotate(-90)")
      .attr("y", (width / 1.18) + margin.top + margin.bottom + 20)
      .attr("x", 0 - (height / 2))
      .attr("dy", "1.5em")
      .style("font-size", "13px")
      .style("font-family", "openSans_regular")
      .style("text-anchor", "middle")
      .text("Partial Dependency");

    svg.append("text")
      .attr("transform",
        "translate(" + (width / 2) + ", " + (height + margin.top + margin.bottom + 20) + ")")
      .style("text-anchor", "middle")
      .style("font-family", "openSans_regular")
      .attr("dy", "-3em")
      .style("font-size", "13px")
      .text("Dependency");
  };
}


