import { Component, OnInit, ElementRef, EventEmitter, Output, ViewChild, Input } from '@angular/core';
import * as d3 from 'd3';
import * as _ from "lodash";
import * as d3Tip from 'd3-tip';
import { PredictiveTabServiceService } from 'src/app/common/services/predictive-services/predictive-tab-service.service';
import { CapitalizePipe, Utils } from 'src/app/common/shared/utility';

@Component({
  selector: 'app-predictive-tree-map',
  templateUrl: './predictive-tree-map.component.html',
  styleUrls: ['./predictive-tree-map.component.css']
})
export class PredictiveTreeMapComponent implements OnInit {
  subscription: any
  temp: any = {}
  percent_achivement: any = {}

  temp_dict = []
  tipObject: any;
  breadcrumb_data: any = {}
  chartData: any;
  filters: any = {}
  flatData: any = {}
  private currElement: HTMLElement;
  private htmlElement: HTMLElement;
  private elmWidth;

  @ViewChild('chartContainer') element: ElementRef;
  private capitalize = CapitalizePipe.prototype.transform;

  constructor(private api: PredictiveTabServiceService, private elRef: ElementRef) {
    this.currElement = elRef.nativeElement
  }

  @Output() filter_values = new EventEmitter<any>();
  @Output() predic_perf = new EventEmitter<any>();

  ngOnInit() {
    let self = this;
    this.elmWidth = this.element.nativeElement.offsetWidth;
    self.tipObject = (<any>d3Tip)()
      .attr('class', 'd3-tip d3-tip-treemap')
      .offset([-10, 0])
      .html(function (d) {
        return '<p><span class="title"> ' + '</span>' + d.id + '</p>'
          + '<p><span class="title">' + "A Count" + ': </span>' + d["data"].a_count + '</p>'
          + '<p><span class="title">' + "B Count" + ': </span>' + d["data"].b_count + '</p>'
          + '<p><span class="title">' + "C Count" + ': </span>' + d["data"].c_count + '</p>'
          + '<p><span class="title">' + "D Count" + ': </span>' + d["data"].d_count + '</p>'
          + '<p><span class="title">' + "Total Count" + ': </span>' + d["data"].total_count + '</p>';
      });

    this.filters.oprn_cat_tree = ""
    this.filters.branch = ""
    this.filters.area = ""
    this.filters.divisions = ""
    this.filters.reporting_office_name = ""
    this.filters.reporting_officer_sap_code = ""

    this.fetchChartData(this.filters)
    this.temp_dict = []
  }


  ngOnDestroy() {
    if (this.subscription) {
      this.subscription.unsubscribe();
    }
  }

  ngOnChanges(changes): void {
    let self = this
  }
  fetchChartData(data): void {
    this.api.predictive_tree_map_list(this.filters).subscribe((res: any, ) => {
      this.chartData = res.data;
      this.flatData = [...this.chartData['performer_by_state']]
      this.assign_percent(res)

      this.predic_perf.emit(this.percent_achivement)
      this.buildChart()
    })
  }

  buildChart() {
    var self = this

    if (_.isEmpty(self.chartData.performer_by_state)) {
      Utils.setContainerState(self.currElement, "nodata");
      return;
    };
    Utils.setContainerState(self.currElement, "done-loading");

    if ((!("circle" in this.chartData['performer_by_state'][0]))) {
      var idKey = 'oprn_category'
    } else if ((!("divisions" in this.chartData['performer_by_state'][0]))) {
      var idKey = 'circle'
      let key = "circle"
      this.drawBreadcrumb(key)
    }
    else if ((!("area" in this.chartData['performer_by_state'][0]))) {
      var idKey = 'divisions'
      let key = "divisions"
      this.drawBreadcrumb(key)
    }
    else if ((!("branch" in this.chartData['performer_by_state'][0]))) {
      var idKey = 'area'
      let key = "area"
      this.drawBreadcrumb(key)
    }

    else if ((!("performance_category" in this.chartData['performer_by_state'][0]))) {
      var idKey = 'branch'
      let key = "branch"
      this.drawBreadcrumb(key)
    }
    else {
      var idKey = 'performance_category'
      let key = "performance_category"
      this.drawBreadcrumb(key)
    }

    var valueKey = 'total_count'
    var colorKey = 'performer'

    var margin = { top: 0, left: 0, bottom: 0, right: 0 },
      width = this.elmWidth - margin.left - margin.right,
      height = 470 - margin.top - margin.bottom;

    var color = d3.scaleOrdinal(d3.schemeCategory20);
    $(".treemap").html("");

    var svg = d3.select(".treemap")
      .append("svg")
      .attr("width", this.elmWidth)
      .attr("height", height + margin.left + margin.right),
      chartLayer = svg.append("g").classed("chartLayer", true);

    _.each(this.flatData, function (d) {
      d.name = d[idKey];
      d.value = d.total_count;
      d.temp_data = d
      d.parent = 'Top Level';

    });

    this.flatData.unshift({ "name": "Top Level", "parent": null });

    // convert the flat data into a hierarchy 
    var treeData = d3.stratify()
      .id(function (d) { return d["name"]; })
      .parentId(function (d) { return d['parent']; })
      (this.flatData)
      .sum(function (d) { return d[valueKey]; });


    var treemap = d3.treemap()
      .size([width, height])
      .padding(1)
      .round(true);

    treemap(treeData);

    var root = treeData


    var self = this

    //data bind
    var node = chartLayer
      .selectAll(".node")
      .data(root.leaves(), function (d) { return d["id"] })

    node
      .selectAll("rect")
      .data(root.leaves(), function (d) { return d["id"] })

    node
      .selectAll("text")
      .data(root.leaves(), function (d) { return d["id"] })

    // enter                  
    var newNode = node.enter()
      .append("g")
      .attr("class", "node")

    newNode.append("rect")
    newNode.append("text")

    // update  

    chartLayer
      .selectAll(".node rect")
      .on('mouseover', self.tipObject.show)
      .on('mouseout', self.tipObject.hide)


      .on("click", function (d) {
        self.treeFilter(d["data"], event);
      })

      .style("cursor", "pointer")
      .attr("x", function (d) { return d["x0"] })
      .attr("y", function (d) { return d["y0"] })
      .attr("width", function (d) { return d["x1"] - d["x0"] })
      .attr("height", function (d) { return d["y1"] - d["y0"] })

      .attr("fill", (d) => {


        let max_value = Math.max(d["data"]["temp_data"].a_count, d["data"]["temp_data"].b_count, d["data"]["temp_data"].c_count, d["data"]["temp_data"].d_count)

        let max_count = _.findKey(_.omit(d["data"]["temp_data"], ['total_count']), function (o) { return o == max_value; });

        if (max_count == 'a_count') {
          return "#4ed54e"
        }
        else if (max_count == 'b_count') {
          return "#FFD700"
        }
        else if (max_count == 'c_count') {
          return "#FF8C00"
        }
        else if (max_count == 'd_count') {
          return "#ff2828"

        }
      })

    chartLayer
      .selectAll(".node text")
      .html((d: any) => `<tspan>` + d.data[idKey] + `</tspan><tspan x = "7" dy = "20">` + d.data.total_count + '</tspan>')

      .attr("y", "1.5em")
      .attr("x", "0.5em")
      .attr("font-size", "0.8em")
      .attr("transform", function (d) { return "translate(" + [d["x0"], d["y0"]] + ")" });
    svg.call(self.tipObject);
  }

  treeFilter(ss, event) {

    if ((!("circle" in this.chartData['performer_by_state'][0]))) {
      this.filters.oprn_cat_tree = ss.oprn_category
      this.filter_values.emit({ "oprn_cat_tree": this.filters.oprn_cat_tree, "circle": "", "divisions": "", "area": "", "branch": "", "reporting_office_name": "", "reporting_officer_sap_code": "" });
    } else if ((!("divisions" in this.chartData['performer_by_state'][0]))) {

      this.filters.circle = ss.circle
      this.filters.oprn_cat_tree = ss.oprn_category

      this.filter_values.emit({ "oprn_cat_tree": this.filters.oprn_cat_tree, "circle": this.filters.circle, "divisions": "", "area": "", "branch": "", "reporting_office_name": "", "reporting_officer_sap_code": "" });
    } else if ((!("area" in this.chartData['performer_by_state'][0]))) {
      this.filters.divisions = ss.divisions
      this.filters.circle = ss.circle
      this.filters.oprn_cat_tree = ss.oprn_category
      this.filter_values.emit({ "oprn_cat_tree": this.filters.oprn_cat_tree, "circle": this.filters.circle, "divisions": this.filters.divisions, "area": "", "branch": "", "reporting_office_name": "", "reporting_officer_sap_code": "" });
    }
    else if ((!("branch" in this.chartData['performer_by_state'][0]))) {
      this.filters.area = ss.area
      this.filters.divisions = ss.divisions
      this.filters.circle = ss.circle
      this.filters.oprn_cat_tree = ss.oprn_category

      this.filter_values.emit({ "oprn_cat_tree": this.filters.oprn_cat_tree, "circle": this.filters.circle, "divisions": this.filters.divisions, "area": this.filters.area, "branch": "", "reporting_office_name": "", "reporting_officer_sap_code": "" });
    }
    else if ((!("performance_category" in this.chartData['performer_by_state'][0]))) {
      this.filters.area = ss.area
      this.filters.divisions = ss.divisions
      this.filters.circle = ss.circle
      this.filters.oprn_cat_tree = ss.oprn_category
      this.filters.branch = ss.branch

      this.filter_values.emit(
        { "oprn_cat_tree": this.filters.oprn_cat_tree, "circle": this.filters.circle, "divisions": this.filters.divisions, "area": this.filters.area, "branch": this.filters.branch });
    }

    else if ((("performance_category" in this.chartData['performer_by_state'][0]))) {
      console.log(ss)
      this.filters.area = ss.area
      this.filters.divisions = ss.divisions
      this.filters.circle = ss.circle
      this.filters.oprn_cat_tree = ss.oprn_category
      this.filters.branch = ss.branch

      this.filter_values.emit(
        { "oprn_cat_tree": this.filters.oprn_cat_tree, "circle": this.filters.circle, "divisions": this.filters.divisions, "area": this.filters.area, "branch": this.filters.branch,"performence_category":ss.performance_category });
    }

    this.api.predictive_tree_map_list(this.filters).subscribe((res: any, ) => {
      this.chartData = res.data
      this.flatData = [...res.data["performer_by_state"]]
      this.assign_percent(res)

      this.predic_perf.emit(this.percent_achivement)
      this.buildChart()
    })
  }

  databack(data, name) {
    var item = this.breadcrumb_data[name]
    if (item == "circle") {

      var current_oprn_cat = this.chartData['performer_by_state'][0].oprn_category + "(Oprn-Cat)"
      this.temp_dict = [current_oprn_cat, "Circle"]
      this.filters.circle = ""
      this.filters.branch = ""
      this.filters.divisions = ""
      this.filters.area = ""
      this.filters.reporting_office_name = ""
      this.filters.reporting_officer_sap_code = ""

      this.filter_values.emit({
        "oprn_cat_tree": this.filters.oprn_cat_tree, "branch": "", "divisions": "", "area": "", "circle": "", "reporting_office_name": "",
        "reporting_officer_sap_code": ""
      });
    } else if (item == "divisions") {

      var current_oprn_cat = this.chartData['performer_by_state'][0].oprn_category + "(Oprn-Cat)"
      var circle = this.chartData['performer_by_state'][0].circle + "(Circle)"
      this.temp_dict = [current_oprn_cat, circle, "divisions"]
      this.filters.divisions = ""
      this.filters.branch = ""
      this.filters.area = ""
      this.filters.reporting_office_name = ""
      this.filters.reporting_officer_sap_code = ""

      this.filter_values.emit({
        "oprn_cat_tree": this.filters.oprn_cat_tree, "circle": this.filters.circle, "branch": "", "divisions": "", "area": "", "reporting_office_name": "",
        "reporting_officer_sap_code": ""
      });

    } else if (item == "area") {

      var current_oprn_cat = this.chartData['performer_by_state'][0].oprn_category + "(Oprn-Cat)"
      var circle = this.chartData['performer_by_state'][0].circle + "(Circle)"
      var divisions = this.chartData['performer_by_state'][0].circle + "(Division)"

      this.filters.divisions = this.chartData['performer_by_state'][0].divisions
      this.filters.branch = ""
      this.filters.area = ""
      this.filters.reporting_office_name = ""
      this.filters.reporting_officer_sap_code = ""
      this.temp_dict = [current_oprn_cat, circle, divisions, "Area"]
      this.filter_values.emit({
        "oprn_cat_tree": this.filters.oprn_cat_tree, "circle": this.filters.circle, "branch": "", "divisions": this.filters.divisions, "area": "", "reporting_office_name": "",
        "reporting_officer_sap_code": ""
      });

    } else if (item == "branch") {

      var current_oprn_cat = this.chartData['performer_by_state'][0].oprn_category + "(Oprn-Cat)"
      var circle = this.chartData['performer_by_state'][0].circle + "(Circle)"
      var divisions = this.chartData['performer_by_state'][0].divisions + "(Division)"
      var area = this.chartData['performer_by_state'][0].area + "(Area)"

      this.filters.divisions = this.chartData['performer_by_state'][0].divisions
      this.filters.area = this.chartData['performer_by_state'][0].area
      this.filters.branch = ""
      this.filters.reporting_office_name = ""
      this.filters.reporting_officer_sap_code = ""
      this.temp_dict = [current_oprn_cat, circle, divisions, area, "Branch"]
      this.filter_values.emit({
        "oprn_cat_tree": this.filters.oprn_cat_tree, "circle": this.filters.circle, "branch": "", "divisions": this.filters.divisions, "area": "", "reporting_office_name": "",
        "reporting_officer_sap_code": ""
      });

    }
    else if (item == "Oprn_category") {
      this.temp_dict = []
      this.filters.oprn_cat_tree = ""
      this.filters.divisions =
        this.filters.circle = ""
      this.filters.area =
        this.filters.branch = ""
      this.filters.reporting_office_name = ""
      this.filters.reporting_officer_sap_code = ""
      this.filter_values.emit({
        "oprn_cat_tree": "", "circle": "", "branch": "", "divisions": "", "area": "", "reporting_office_name": "",
        "reporting_officer_sap_code": ""
      });

    }
    else if (item == "reporting_office_name") {
      var current_oprn_cat = this.chartData['performer_by_state'][0].oprn_category + "(Oprn-Cat)"
      var circle = this.chartData['performer_by_state'][0].circle + "(Circle)"
      var divisions = this.chartData['performer_by_state'][0].divisions + "(Division)"
      var area = this.chartData['performer_by_state'][0].area + "(Area)"
      var branch = this.chartData['performer_by_state'][0].branch + "(Branch)"
      this.filters.reporting_office_name = ""
      this.filters.reporting_officer_sap_code = ""
      this.temp_dict = [current_oprn_cat, circle, divisions, area, branch, "reporting_office_name"]
      this.filters.reporting_office_name = ""
      this.filters.reporting_officer_sap_code = ""
      this.filter_values.emit({
        "oprn_cat_tree": this.filters.oprn_cat_tree, "circle": this.filters.circle, "branch": this.filters.branch, "divisions": this.filters.divisions, "area": this.filters.area, "reporting_office_name": "",
        "reporting_officer_sap_code": ""
      });
    }

    this.api.predictive_tree_map_list(this.filters).subscribe((res: any, ) => {
      this.chartData = res.data;
      this.flatData = [...res.data["performer_by_state"]]
      this.assign_percent(res)

      this.predic_perf.emit(this.percent_achivement)
      this.buildChart()
    })
  }


  drawBreadcrumb(data) {
    if (data == "circle") {
      var current_oprn_cat = this.chartData['performer_by_state'][0].oprn_category + "(Oprn-Cat)"
      this.breadcrumb_data = { [current_oprn_cat]: "Oprn_category" }
      this.temp_dict = [current_oprn_cat, "circle"]
    }
    if (data == "divisions") {
      var current_oprn_cat = this.chartData['performer_by_state'][0].oprn_category + "(Oprn-Cat)"
      var current_circle = this.chartData['performer_by_state'][0].circle + "(Circle)"

      this.breadcrumb_data = { [current_oprn_cat]: "Oprn_category", [current_circle]: "circle" }

      this.temp_dict = [current_oprn_cat, current_circle, "Division"]
    }
    if (data == "area") {

      var current_oprn_cat = this.chartData['performer_by_state'][0].oprn_category + "(Oprn-Cat)"
      var currenct_circle = this.chartData['performer_by_state'][0].circle + "(Circle)"
      var current_divisions = this.chartData['performer_by_state'][0].divisions + "(Division)"

      this.breadcrumb_data = { [current_oprn_cat]: "Oprn_category", [currenct_circle]: "circle", [current_divisions]: "divisions" }
      this.temp_dict = this.temp_dict = [current_oprn_cat, currenct_circle, current_divisions, "Area"]
    }
    if (data == "branch") {

      var current_oprn_cat = this.chartData['performer_by_state'][0].oprn_category + "(Oprn-Cat)"
      var current_divisions = this.chartData['performer_by_state'][0].divisions + "(Division)"
      var currenct_circle = this.chartData['performer_by_state'][0].circle + "(Circle)"
      var area = this.chartData['performer_by_state'][0].area + "(Area)"

      this.breadcrumb_data = { [current_oprn_cat]: "Oprn_category", [current_divisions]: "divisions", [area]: "area", [currenct_circle]: "circle" }
      this.temp_dict = this.temp_dict = [current_oprn_cat, currenct_circle, current_divisions, area, "Branch"]
    }
    if (data == "performance_category") {

      var current_oprn_cat = this.chartData['performer_by_state'][0].oprn_category + "(Oprn-Cat)"
      var current_divisions = this.chartData['performer_by_state'][0].divisions + "(Division)"
      var area = this.chartData['performer_by_state'][0].area + "(Area)"
      var currenct_circle = this.chartData['performer_by_state'][0].circle + "(Circle)"
      var branch = this.chartData['performer_by_state'][0].branch + "(Branch)"
      // var reporting_office_name = this.chartData['performer_by_state'][0].reporting_office_name+"(Repo_off)"

      this.breadcrumb_data = { [current_oprn_cat]: "Oprn_category", [current_divisions]: "divisions", [area]: "area", [currenct_circle]: "circle", [branch]: "branch" }
      this.temp_dict = this.temp_dict = [current_oprn_cat, currenct_circle, current_divisions, area, branch, "Per-Category"]
    }
  }

  assign_percent(data){

    this.percent_achivement.a = (data.avg_percent.A) * 100
    this.percent_achivement.b = (data.avg_percent.B) * 100
    this.percent_achivement.c = (data.avg_percent.C) * 100
    this.percent_achivement.d = (data.avg_percent.D) * 100

  }
}
