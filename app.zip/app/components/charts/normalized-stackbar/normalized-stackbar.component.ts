import { Component, OnInit, Input, ViewChild, ElementRef, OnChanges, Output } from '@angular/core';
import * as d3 from 'd3';
import * as d3Tip from "d3-tip"
import * as _ from 'lodash';
import { Utils, CapitalizePipe } from 'src/app/common/shared/utility';
import { EventEmitter } from '@angular/core';

@Component({
  selector: 'app-normalized-stackbar',
  templateUrl: './normalized-stackbar.component.html',
  styleUrls: ['./normalized-stackbar.component.css']
})

export class NormalizedStackbarComponent implements OnInit {
  private host;
  private svg;
  private tipObject;
  private margin;
  private width;
  private height;
  private xScale;
  private yScale;
  private colorScale;
  private currElement: HTMLElement;
  private htmlElement: HTMLElement;
  private elmWidth;

  private capitalize = CapitalizePipe.prototype.transform;

  @Input() chart_height:any = 340
  @Input() percentData : any;
  @Output() barClick : EventEmitter<any> = new EventEmitter();
  @ViewChild('chartContainer') element: ElementRef;

  constructor(private elRef: ElementRef) {
    this.currElement = this.elRef.nativeElement;
  }

  ngOnInit() {
    let self = this
    this.tipObject = (<any>d3Tip)()
    .attr('class', 'd3-tip d3-tip-stacked-bar')
    .offset([-10, 0])
    .html(function (d) {
      return '<p><span class="title">' + d.data.x + ' : ' + '</span>' + d.data.key + '</p>'
          + '<p><span class="title">' + self.capitalize(d.serieKey).replace("Count", "Percent") + ': </span>' + ((d[1] - d[0])*100).toFixed(1) + '%' + '</p>';
    });
    // this.normStackedBar()
  }
  
  ngOnChanges(changes): void {
    let self = this;    

    if (changes.percentData && changes.percentData.currentValue !== undefined) {
      Utils.setContainerState(self.currElement,'loading');
      setTimeout(function () {
        self.normStackedBar();
      }, 500);
    }
    this.elmWidth = this.element.nativeElement.offsetWidth;
    this.htmlElement = this.element.nativeElement;
    this.host = d3.select(this.htmlElement);
    this.setup();
  }

  private setup(): void {
    this.margin = {   top: 60, right: 30, bottom: 45, left: 60 };
    this.width = this.elmWidth - this.margin.left - this.margin.right;
    this.height = this.chart_height - this.margin.top - this.margin.bottom;
    this.xScale = d3.scaleBand().rangeRound([this.width, 0])
      .padding(0.3)
      .align(0.3);
    this.yScale = d3.scaleLinear()
      .range([this.height, 0])
    this.colorScale = d3.scaleOrdinal()
      .range(["#ff2828","	#FF8C00" , "#FFD700", "#4ed54e"])
      .domain(["d_count", "c_count", "b_count","a_count"]);
  }


  // ** STACKED BAR CHART **//

  normStackedBar(){
    let self = this;
    self.host.html('');

    if (_.isEmpty(self.percentData)) {
      Utils.setContainerState(self.currElement, "nodata");
      return;
    };
    Utils.setContainerState(self.currElement, "done-loading");
    
    
    let columns: any = _.chain(self.percentData[0]).omit(['key', 'total',"x"]).keys().value();
        
    self.svg = self.host.append('svg')
      .attr('width', self.width + self.margin.left + self.margin.right)
      .attr('height', self.height + self.margin.top + self.margin.bottom);

    let mainG = self.svg.append("g")
      .attr("transform",
        "translate(" + self.margin.left + "," + self.margin.top + ")");

    var stack = d3.stack()
      .order(d3.stackOrderNone)
      .offset(d3.stackOffsetExpand);  
    
    let x_lable = self.percentData;
  
    self.xScale.domain(self.percentData.map(function (d) {
      return d.key; }).reverse());

      let stackData = stack.keys(columns)(self.percentData);
    _.each(stackData, function(serie) {
      serie.forEach(function(d) {
        d.serieKey = serie.key;
      });
    });


    let serie = mainG.selectAll(".serie")
      // .data(stack.keys(columns)(self.percentData))
      .data(stackData)
      .enter().append("g")
        .attr("class",  function(d) {
          return "serie " + d.key;
        })
        .attr("fill", function (d) {
          return self.colorScale(d.key); })
          .attr("data-class", function(d) {
            return d.key;
          });

    serie.selectAll("rect")
        .data(function (d) { return d; })
      .enter().append("rect")
        .attr("x", function (d: any) { return self.xScale(d.data.key); })
        .attr("y", function (d) { return self.yScale(d[1]); })
        .attr("height", function (d) { return self.yScale(d[0]) - self.yScale(d[1]); })
        .attr("width", self.xScale.bandwidth())
        .on('mouseover', self.tipObject.show)
        .on('mouseout', self.tipObject.hide);
  
      self.svg.call(self.tipObject);

    mainG.append("g")
        .attr("class", "axis axis--x")
        .attr("transform", "translate(0," + self.height + ")")
        .call(d3.axisBottom(self.xScale))
      .selectAll("text")
        .attr("y", 15)
        .attr("x", -10)
        .attr("dy", ".35em")
        .attr("transform", "rotate(-20)")
        .style("text-anchor", "middle");

    // text label for the y axis
    mainG.append("text")
      .attr("transform", "rotate(-90)")
      .attr("y", 0 - this.margin.left)
      .attr("x",0 - (this.height / 2))
      .attr("dy", "1.5em")
      .style("font-size","13px")
      .style("font-family","openSans_regular")
      .style("text-anchor", "middle")
      .text("Performance");         

    mainG.append("g")
        .attr("class", "axis axis--y")
        .call(d3.axisLeft(self.yScale).ticks(10, "%"))

    // text label for the x axis
    mainG.append("text")             
      .attr("transform",
            "translate(" + (this.width/2) + " ," + (this.height + this.margin.top + 20) + ")")
      .style("text-anchor", "middle")
      .style("font-family","openSans_regular")
      .attr("dy", "-3em")
      .style("font-size","13px")
      .text(x_lable[0].x);
  }
}
