import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';

import * as d3 from 'd3';
import * as _ from "lodash";
import * as d3Tip from 'd3-tip';
import { ModelHealthService } from 'src/app/common/services/predictive-services/model-health.service';
import { Utils } from 'src/app/common/shared/utility';

@Component({
  selector: 'app-line-chart',
  templateUrl: './line-chart.component.html',
  styleUrls: ['./line-chart.component.css']
})
export class LineChartComponent implements OnInit {
  x: any;
  auc_value: any
  auc_b_value: any
  auc_a_value: any
  auc_c_value: any
  auc_d_value: any

  @ViewChild('chartContainer') element: ElementRef;
  private elmWidth;
  y: any;
  private currElement: HTMLElement;
  private htmlElement: HTMLElement;
  line_chart_data = [];
  line_chart_data_a = [];
  line_chart_data_b = [];
  line_chart_data_c = [];
  line_chart_data_d = [];


  tipObject;
  constructor(private api: ModelHealthService, private elRef: ElementRef) {
    this.currElement = this.elRef.nativeElement;
  }

  ngOnInit() {

    this.elmWidth = this.element.nativeElement.offsetWidth;
    this.htmlElement = this.element.nativeElement;

    this.tipObject = (<any>d3Tip)()
      .attr('class', 'd3-tip d3-tip-treemap')
      .offset([-10, 0])
      .html(function (d) {
        return '<p><span style = "color:red;"> ' + '</span>' + "TRUE_POS :" + d["true_pos"] + '</p>' +
          '<p><span style = "color:red;"> ' + '</span>' + "FALSE_POS :" + d["false_pos"] + '</p>';
      }
      );

    this.fetch_line_chart_data()
  }


  fetch_line_chart_data() {
    let self = this
    this.api.get_line_chart_data().subscribe((res: any) => {
      self.line_chart_data_a = res.data_A
      self.line_chart_data_b = res.data_B
      self.line_chart_data_c = res.data_C
      self.line_chart_data_d = res.data_D
      if (_.isEmpty(self.line_chart_data_a && self.line_chart_data_b && self.line_chart_data_c && self.line_chart_data_d)) {
        Utils.setContainerState(self.currElement, "nodata");
        return;
      };
      Utils.setContainerState(self.currElement, "done-loading");
      self.auc_a_value = res.Auc_A
      self.auc_b_value = res.Auc_B
      self.auc_c_value = res.Auc_C
      self.auc_d_value = res.Auc_D

      self.build_chart()
    });

  }

  build_chart() {
    d3.select(".line_chart").html("")

    var margin = { top: 50, right: 50, bottom: 50, left: 50 },
      width = this.elmWidth - margin.left - margin.right,
      height = 520 - margin.top - margin.bottom;

    this.x = d3.scaleLinear().range([0, width]).domain([0, 1]);
    this.y = d3.scaleLinear().range([height, 0]).domain([0, 1]);

    var self = this

    var parseTime = d3.timeParse("%d-%b-%y");

    // define the line
    var valueline_a = d3.line()
      .x(function (d) { return self.x(d["false_pos_A"]); })
      .y(function (d) { return self.y(d["true_pos_A"]); });

    var valueline_b = d3.line()
      .x(function (d) { return self.x(d["false_pos_B"]); })
      .y(function (d) { return self.y(d["true_pos_B"]); });


    var valueline_c = d3.line()
      .x(function (d) { return self.x(d["false_pos_C"]); })
      .y(function (d) { return self.y(d["true_pos_C"]); });

    var valueline_d = d3.line()
      .x(function (d) { return self.x(d["false_pos_D"]); })
      .y(function (d) { return self.y(d["true_pos_D"]); });

    // append the svg obgect to the body of the page
    // appends a 'group' element to 'svg'
    // moves the 'group' element to the top left margin
    var svg = d3.select(".line_chart").append("svg")
      .attr("width", width + margin.left + margin.right)
      .attr("height", height + margin.top + margin.bottom + 10)
      .append("g")
      .attr("transform",
        "translate(" + 60 + "," + margin.top + ")");


    // Get the data
    // format the data
    this.line_chart_data_b.forEach(function (d) {

      d.true_pos_A = d["true_pos_B"];
      d.false_pos_A = d["false_pos_B"];
    }
    );
    this.line_chart_data_a.forEach(function (d) {

      d.true_pos_A = d["true_pos_A"];
      d.false_pos_A = d["false_pos_A"];
    }
    );
    this.line_chart_data_c.forEach(function (d) {

      d.true_pos_A = d["true_pos_C"];
      d.false_pos_A = d["false_pos_C"];
    }
    );
    this.line_chart_data_d.forEach(function (d) {

      d.true_pos_A = d["true_pos_D"];
      d.false_pos_A = d["false_pos_D"];
    }
    );

    // Scale the range of the data
    // this.x.domain(d3.extent(this.line_chart_data, function (d) { return d["false_pos"]; }));
    // this.y.domain([0, d3.max(this.line_chart_data, function (d) { return d["true_pos"]; })]);

    // Add the valueline path.


    svg.append("path")
      .data([this.line_chart_data_a])
      .attr("class", "line")
      .attr("d", valueline_a)
      .attr("stroke", "#4ed54e")
    svg.append("path")
      .data([this.line_chart_data_b])
      .attr("class", "line")
      .attr("d", valueline_b)
      .attr("stroke", "#FFD700")
    svg.append("path")
      .data([this.line_chart_data_c])
      .attr("class", "line")
      .attr("d", valueline_c)
      .attr("stroke", "#FF8C00")
    svg.append("path")
      .data([this.line_chart_data_d])
      .attr("class", "line")
      .attr("d", valueline_d)
      .attr("stroke", "#ff2828")
    svg.call(this.tipObject);

    // Add the X Axis
    svg.append("g")
      .attr("transform", "translate(0," + height + ")")
      .call(d3.axisBottom(this.x));

    // Add the Y Axis
    svg.append("g")
      .call(d3.axisLeft(this.y));


    svg.append('line')
      .attr('id', 'baseline')
      .attr("x1", 0)
      .attr("x2", width)
      .attr("y1", height)
      .attr("y", 0)
      .attr("stroke", "black")
      .attr("opacity", "0.8")
      .attr("stroke-dasharray", "5,5");

    svg.append("text")
      .attr("transform", "rotate(-90)")
      .attr("y", 0 - margin.left)
      .attr("x", 0 - (height / 2))
      .attr("dy", "1.5em")
      .style("font-size", "13px")
      .style("font-family", "openSans_regular")
      .style("text-anchor", "middle")
      .text("False positive");

    svg.append("text")
      .attr("transform",
        "translate(" + (width / 2) + ", " + (height + margin.top + margin.bottom - 20) + ")")
      .style("text-anchor", "middle")
      .style("font-family", "openSans_regular")
      .attr("dy", "-3em")
      .style("font-size", "13px")
      .text("True positive");
  }
}
