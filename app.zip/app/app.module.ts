import { BrowserModule } from "@angular/platform-browser";
import { NgModule, ErrorHandler } from "@angular/core";
import { FormsModule } from "@angular/forms";

import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { LoginComponent } from "./components/authentication/login/login.component";
// import { ForgotPasswordComponent } from "./components/authentication/forgot-password/forgot-password.component";
import { DashboardComponent } from "./components/dashboard/dashboard.component";
import { NavbarComponent } from "./components/navbar/navbar.component";
import { AngularMultiSelectModule } from "angular2-multiselect-dropdown";
import * as bootstrap from "bootstrap";
import * as $ from 'jquery';

import { HTTP_INTERCEPTORS, HttpClientModule, HttpClient } from "@angular/common/http";
import { AuthInterceptor } from "./common/services/interceptor.service";
import { CreateUserComponent } from "./components/authentication/create-user/create-user.component";
import { CreateRoleComponent } from "./components/authentication/create-role/create-role.component";
import { ResetPasswordComponent } from "./components/authentication/reset-password/reset-password.component";
import { PasswordValidator } from "./common/directives/password-validator.directive";
import { ChangePasswordComponent } from "./components/authentication/change-password/change-password.component";
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgbModalModule } from '@ng-bootstrap/ng-bootstrap';
import { DataTablesModule } from "angular-datatables";
import { AuthService } from "./common/services/auth.service";
import { ProjectServiceService } from "./common/services/project-service.service";
import { SettingsComponent } from "./components/settings/settings.component";
import { TopManagersTableComponent } from './components/top-managers-table/top-managers-table.component';
import { AreaChartComponent } from "./components/charts/area-chart/area-chart.component";
import { StackbarChartComponent } from "./components/charts/stackbar-chart/stackbar-chart.component";
import { UserManagementComponent } from "./components/admin/user-management/user-management.component";
import { RoleManagementComponent } from "./components/admin/role-management/role-management.component";
import { NormalizedStackbarComponent } from "./components/charts/normalized-stackbar/normalized-stackbar.component";
import { TreeMapComponent } from './components/charts/tree-map/tree-map.component';
import { LoaderComponent } from './components/loader/loader.component';
import { ErrorInterceptor } from "./common/services/errorHandler.service";
import { RoundPipe, CapitalizePipe, NullToDashPipe, ReversePipe, Division, PaddZero } from "./common/shared/utility";

import { ModelHealthComponent } from './components/predictive-analytics/model-health/model-health.component';
import { LineChartComponent } from './components/charts/line-chart/line-chart.component';
import { PredictiveNavComponent } from './components/predictive-analytics/predictive-nav/predictive-nav.component';
import { PredictiveComponent } from './components/predictive-analytics/predictive/predictive.component';
import { PredictiveTreeMapComponent } from './components/charts/predictive-tree-map/predictive-tree-map.component';
import { ParametersBarChartComponent } from './components/charts/parameters-bar-chart/parameters-bar-chart.component';
import { SimulationComponent } from './components/predictive-analytics/simulation/simulation.component';
import { PdbCurveComponent } from './components/charts/pdb-curve/pdb-curve.component';
import { EmpSearchComponent } from './components/predictive-analytics/simulation/emp-search/emp-search.component';
import { PredictiveEmpTableComponent } from './components/predictive-analytics/predictive/predictive-emp-table/predictive-emp-table.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    // ForgotPasswordComponent,
    DashboardComponent,
    CreateUserComponent,
    NavbarComponent,
    CreateRoleComponent,
    ResetPasswordComponent,
    ChangePasswordComponent,
    PasswordValidator,
    UserManagementComponent,
    RoleManagementComponent,
    SettingsComponent,
    StackbarChartComponent,
    AreaChartComponent,
    TopManagersTableComponent,
    NormalizedStackbarComponent,
    TreeMapComponent,
    LoaderComponent,
    RoundPipe, CapitalizePipe, NullToDashPipe, ModelHealthComponent, LineChartComponent,
    PredictiveNavComponent, PredictiveComponent, PredictiveTreeMapComponent,ReversePipe,
    ParametersBarChartComponent,
    SimulationComponent,
    PdbCurveComponent,
    Division,PaddZero, EmpSearchComponent, PredictiveEmpTableComponent
  ],
  imports: [
    NgbModule,
    NgbModalModule,
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    DataTablesModule,
    AngularMultiSelectModule,
  ],
  providers: [
    AuthService,
    ProjectServiceService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    },
      
    { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },

  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

