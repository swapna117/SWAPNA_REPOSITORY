import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { LoginComponent } from "./components/authentication/login/login.component";
// import { ForgotPasswordComponent } from "./components/authentication/forgot-password/forgot-password.component";
import { DashboardComponent } from "./components/dashboard/dashboard.component";
import { AuthGuard } from "./common/guard/auth.guard";
import { CreateUserComponent } from "./components/authentication/create-user/create-user.component";
import { CreateRoleComponent } from "./components/authentication/create-role/create-role.component";
import { ResetPasswordComponent } from "./components/authentication/reset-password/reset-password.component";

import { SettingsComponent } from "./components/settings/settings.component";
import { UserManagementComponent } from "./components/admin/user-management/user-management.component";
import { RoleManagementComponent } from "./components/admin/role-management/role-management.component";
import { LoaderComponent } from "./components/loader/loader.component";
import { ModelHealthComponent } from "./components/predictive-analytics/model-health/model-health.component";
import { PredictiveNavComponent } from "./components/predictive-analytics/predictive-nav/predictive-nav.component";

const routes: Routes = [
  {
    path: "",
    component: LoginComponent
  },
  // {
  //   path: "forgot",
  //   component: ForgotPasswordComponent
  // },
  {
    path: "",
    canActivate: [AuthGuard],
    children: [
      {
        path: "",
        redirectTo: "user_management",
        pathMatch: "full"
      },
      {
        path: "user_management",
        component: UserManagementComponent
      },
      {
        path: "role_management",
        component: RoleManagementComponent
      },
      {
        path: "loader",
        component: LoaderComponent,
      },
    ]
  },
  {
    path: "create_user",
    component: CreateUserComponent,
    canActivate: [AuthGuard]
  },
  {
    path: "descriptive-analytics",
    component: DashboardComponent,
    canActivate: [AuthGuard]
  },
  {
    path: "create_role",
    component: CreateRoleComponent,
    canActivate: [AuthGuard]
  },
  {
    path: "settings",
    component: SettingsComponent,
    canActivate: [AuthGuard]
  },
  {
    path: "reset_password",
    component: ResetPasswordComponent,
    canActivate: [AuthGuard]
  },
  {
    path: "predictive-analytics",
    component: PredictiveNavComponent,
    canActivate: [AuthGuard]
  },
  
  // {
  //   path:"**",

  // }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {}
